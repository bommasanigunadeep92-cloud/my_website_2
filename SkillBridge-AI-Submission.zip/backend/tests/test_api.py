import os
import sys

# Ensure backend directory is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

os.environ["DISABLE_SQLALCHEMY_CEXT"] = "1"
os.environ["DATABASE_URL"] = "sqlite:///./test_skillbridge.db"

import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.core.database import Base, engine
from app.seed.seed_data import run_seed

client = TestClient(app)

@pytest.fixture(scope="session", autouse=True)
def setup_test_db():
    run_seed()
    yield

def test_root_and_health():
    resp = client.get("/")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "operational"
    assert "SkillBridge AI" in data["app"]

    health = client.get("/health")
    assert health.status_code == 200
    assert health.json()["status"] == "healthy"

def test_auth_login_learner():
    resp = client.post("/api/v1/auth/login", json={
        "email": "alex@acme.com",
        "password": "LearnerPass123!"
    })
    assert resp.status_code == 200
    data = resp.json()
    assert "access_token" in data
    assert data["user"]["email"] == "alex@acme.com"
    assert data["user"]["role"] == "LEARNER"

def test_auth_login_invalid():
    resp = client.post("/api/v1/auth/login", json={
        "email": "alex@acme.com",
        "password": "WrongPassword123!"
    })
    assert resp.status_code == 401

def test_skills_gap_analysis():
    # Login as Alex
    login_resp = client.post("/api/v1/auth/login", json={
        "email": "alex@acme.com",
        "password": "LearnerPass123!"
    })
    token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    resp = client.get("/api/v1/skills/gap-analysis", headers=headers)
    assert resp.status_code == 200
    data = resp.json()
    assert "target_role" in data
    assert "radar_data" in data
    assert len(data["radar_data"]) > 0
    assert "overall_readiness_pct" in data

def test_missions_list_and_submission():
    login_resp = client.post("/api/v1/auth/login", json={
        "email": "alex@acme.com",
        "password": "LearnerPass123!"
    })
    token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    resp = client.get("/api/v1/missions", headers=headers)
    assert resp.status_code == 200
    missions = resp.json()
    assert len(missions) >= 3

    m_id = missions[0]["id"]
    # Test submission
    sub_resp = client.post(f"/api/v1/missions/{m_id}/submit", headers=headers, json={
        "submission_content": "SELECT tier, SUM(amount) OVER (PARTITION BY tier ORDER BY transaction_date) AS running_total FROM transactions WHERE status != 'refunded';"
    })
    assert sub_resp.status_code == 200
    sub_data = sub_resp.json()
    assert sub_data["score"] >= 60.0
    assert "rubric_breakdown" in sub_data
    assert len(sub_data["rubric_breakdown"]) > 0

def test_scenario_flow():
    login_resp = client.post("/api/v1/auth/login", json={
        "email": "alex@acme.com",
        "password": "LearnerPass123!"
    })
    token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    resp = client.get("/api/v1/scenarios", headers=headers)
    assert resp.status_code == 200
    scenarios = resp.json()
    assert len(scenarios) >= 3

    sc_id = scenarios[0]["id"]
    detail_resp = client.get(f"/api/v1/scenarios/{sc_id}", headers=headers)
    assert detail_resp.status_code == 200
    assert "steps" in detail_resp.json()

def test_failure_prevention_flow():
    login_resp = client.post("/api/v1/auth/login", json={
        "email": "alex@acme.com",
        "password": "LearnerPass123!"
    })
    token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # Fetch skills to get ID
    sk_resp = client.get("/api/v1/skills", headers=headers)
    sk_id = sk_resp.json()[0]["id"]

    # Submit difficulty report
    rep_resp = client.post("/api/v1/failure-prevention/reports", headers=headers, json={
        "skill_id": sk_id,
        "topic": "Window Functions Frame Clauses",
        "description": "Difficulty understanding RANGE BETWEEN versus ROWS BETWEEN",
        "error_snippet": "Syntax error at or near UNBOUNDED",
        "emotional_blocker": "Confused on frame semantics",
        "is_anonymous": False
    })
    assert rep_resp.status_code == 200

    # Check patterns
    pat_resp = client.get("/api/v1/failure-prevention/patterns", headers=headers)
    assert pat_resp.status_code == 200
    patterns = pat_resp.json()
    assert len(patterns) >= 1

def test_knowledge_radar_and_spof():
    login_resp = client.post("/api/v1/auth/login", json={
        "email": "manager@acme.com",
        "password": "ManagerPass123!"
    })
    token = login_resp.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    resp = client.get("/api/v1/knowledge/radar/analytics", headers=headers)
    assert resp.status_code == 200
    analytics = resp.json()
    assert "total_articles" in analytics
    assert "overall_coverage_health_pct" in analytics
    assert "spof_alerts" in analytics

def test_passport_public_share():
    # Public endpoint without auth
    resp = client.get("/api/v1/passport/public/alex-rivera-verified-2026")
    assert resp.status_code == 200
    passport = resp.json()
    assert passport["user_name"] == "Alex Rivera"
    assert passport["verified_badge"] == True
    assert len(passport["evidence_items"]) >= 3
