import os
import sys

# Ensure pure-python mode for environments with restricted C-extension loading
os.environ["DISABLE_SQLALCHEMY_CEXT"] = "1"

from datetime import datetime, timezone, timedelta

# Add backend to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from app.core.database import SessionLocal, Base, engine
from app.core.security import get_password_hash
from app.models.enums import (
    UserRole,
    SkillDemonstrationLevel,
    MissionDifficulty,
    SubmissionStatus,
    EvidenceType,
    SpofRiskLevel,
    InterventionStatus,
    CrossTrainingStatus,
    QuestionType
)
from app.models.user import Organization, User, Notification, AuditLog
from app.models.skill import Skill, RoleRequirement, UserSkillScore, RoadmapMilestone, LearningResource
from app.models.assessment import Assessment, AssessmentQuestion, AssessmentAttempt
from app.models.mission import Mission, MissionSubmission
from app.models.failure_prevention import FailureReport, FailurePattern, InterventionTracking
from app.models.scenario import Scenario, ScenarioStep, ScenarioAttempt
from app.models.knowledge import KnowledgeArticle, CrossTrainingAssignment
from app.models.passport import SkillPassport, PassportEvidence

def run_seed():
    print("Starting SkillBridge AI Database Seeding...")
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    try:
        # Check if already seeded
        if db.query(Organization).filter(Organization.slug == "acme-corp").first():
            print("Database already contains seed data. Refreshing demo metrics...")
            return

        now = datetime.now(timezone.utc)

        # 1. Organization
        org = Organization(
            name="Acme Global Technologies",
            slug="acme-corp",
            domain="acmeglobal.com",
            settings={"industry": "Enterprise Software & Cloud Platforms", "tier": "Enterprise"}
        )
        db.add(org)
        db.flush()
        print(f"Created Organization: {org.name}")

        # 2. Users
        admin_user = User(
            email="admin@acme.com",
            hashed_password=get_password_hash("AdminPass123!"),
            full_name="Sarah Chen",
            role=UserRole.ADMIN,
            organization_id=org.id,
            department="Executive & Talent Architecture",
            job_title="VP of Engineering & Talent Development",
            target_role="Chief Technology Officer"
        )

        manager_user = User(
            email="manager@acme.com",
            hashed_password=get_password_hash("ManagerPass123!"),
            full_name="Marcus Brody",
            role=UserRole.MANAGER,
            organization_id=org.id,
            department="Platform & Infrastructure",
            job_title="Engineering Director & Technical Mentor",
            target_role="VP of Systems Architecture"
        )

        learner1 = User(
            email="alex@acme.com",
            hashed_password=get_password_hash("LearnerPass123!"),
            full_name="Alex Rivera",
            role=UserRole.LEARNER,
            organization_id=org.id,
            department="Product Engineering",
            job_title="Software Associate",
            target_role="Senior Full-Stack Engineer"
        )

        learner2 = User(
            email="maya@acme.com",
            hashed_password=get_password_hash("LearnerPass123!"),
            full_name="Maya Patel",
            role=UserRole.LEARNER,
            organization_id=org.id,
            department="Data Analytics",
            job_title="Junior Data Analyst",
            target_role="Cloud Data & Analytics Specialist"
        )

        learner3 = User(
            email="liam@acme.com",
            hashed_password=get_password_hash("LearnerPass123!"),
            full_name="Liam Vance",
            role=UserRole.LEARNER,
            organization_id=org.id,
            department="DevOps & Reliability",
            job_title="Operations Engineer",
            target_role="DevOps & Reliability Engineer"
        )

        db.add_all([admin_user, manager_user, learner1, learner2, learner3])
        db.flush()
        print("Created Demo Users (Sarah Chen [Admin], Marcus Brody [Manager], Alex Rivera [Learner], Maya Patel [Learner], Liam Vance [Learner])")

        # 3. Skills
        skills_data = [
            ("SQL & Query Optimization", "Data & Analytics", "Proficiency in complex relational joins, window analytical functions, indexes, execution plans, and query performance tuning."),
            ("Frontend Architecture & TypeScript", "Software Engineering", "Modern modular React systems, type-safe state machines, reactive rendering cycles, accessibility standards, and component libraries."),
            ("Cloud Infrastructure & Containers", "DevOps & Cloud", "Docker containerization, Kubernetes cluster primitives, zero-downtime rolling deploys, and cloud infrastructure as code."),
            ("Consequence-Driven Incident Management", "Workplace Leadership", "Handling production crisis escalations, rapid triage, executive communications, blameless post-mortems, and customer SLA preservation."),
            ("Enterprise Data Modeling & ETL", "Data & Analytics", "Designing normalized transactional schemas, analytical star schemas, data warehousing pipelines, and idempotency guarantees."),
            ("Cross-Functional Stakeholder Alignment", "Workplace Leadership", "Navigating contentious roadmap trade-offs, engineering vs product disagreements, technical debt prioritization, and consensus building."),
            ("System Observability & Telemetry", "DevOps & Cloud", "Configuring distributed tracing, Prometheus metrics alerts, logging pipelines, and SLO error budget tracking."),
            ("API Security & Access Control", "Software Engineering", "OAuth2/OIDC protocols, JWT token rotation, cryptographic hashing, RBAC/ABAC authorization rules, and zero-trust design.")
        ]

        skill_map = {}
        for name, cat, desc in skills_data:
            sk = Skill(name=name, category=cat, description=desc)
            db.add(sk)
            db.flush()
            skill_map[name] = sk
        print(f"Created {len(skill_map)} Core Skills")

        # 4. Role Requirements for Target Roles
        role_reqs_data = [
            # Senior Full-Stack Engineer
            ("Senior Full-Stack Engineer", "Frontend Architecture & TypeScript", 4.5, 1.4),
            ("Senior Full-Stack Engineer", "SQL & Query Optimization", 4.0, 1.3),
            ("Senior Full-Stack Engineer", "API Security & Access Control", 4.2, 1.2),
            ("Senior Full-Stack Engineer", "Cloud Infrastructure & Containers", 3.5, 1.0),
            ("Senior Full-Stack Engineer", "Cross-Functional Stakeholder Alignment", 3.8, 1.1),

            # Cloud Data & Analytics Specialist
            ("Cloud Data & Analytics Specialist", "SQL & Query Optimization", 4.8, 1.5),
            ("Cloud Data & Analytics Specialist", "Enterprise Data Modeling & ETL", 4.5, 1.4),
            ("Cloud Data & Analytics Specialist", "System Observability & Telemetry", 3.8, 1.1),
            ("Cloud Data & Analytics Specialist", "Cloud Infrastructure & Containers", 3.5, 1.0),

            # DevOps & Reliability Engineer
            ("DevOps & Reliability Engineer", "Cloud Infrastructure & Containers", 4.8, 1.5),
            ("DevOps & Reliability Engineer", "System Observability & Telemetry", 4.5, 1.4),
            ("DevOps & Reliability Engineer", "Consequence-Driven Incident Management", 4.2, 1.3),
            ("DevOps & Reliability Engineer", "API Security & Access Control", 3.8, 1.1)
        ]

        for role_title, s_name, req_lvl, weight in role_reqs_data:
            rr = RoleRequirement(
                role_title=role_title,
                skill_id=skill_map[s_name].id,
                required_level=req_lvl,
                importance_weight=weight,
                organization_id=org.id
            )
            db.add(rr)

        # 5. User Skill Baseline Demonstrations for Alex Rivera
        alex_scores = [
            ("Frontend Architecture & TypeScript", 4.2, SkillDemonstrationLevel.PROFICIENT, 3, "Scored 92% in TypeScript Diagnostic; verified production component architecture"),
            ("SQL & Query Optimization", 2.8, SkillDemonstrationLevel.DEVELOPING, 1, "Completed basic query test (68%); requires practical window function & indexing mastery"),
            ("API Security & Access Control", 3.8, SkillDemonstrationLevel.DEVELOPING, 2, "Verified OAuth2 token flow; developing fine-grained RBAC policies"),
            ("Cloud Infrastructure & Containers", 2.2, SkillDemonstrationLevel.INSUFFICIENT_EVIDENCE, 1, "Demonstrated Docker basics; needs Kubernetes pod lifecycle practice"),
            ("Cross-Functional Stakeholder Alignment", 3.0, SkillDemonstrationLevel.DEVELOPING, 1, "Completed simulator scenario with good conflict resolution rating")
        ]

        for s_name, lvl, status, ev_count, note in alex_scores:
            uss = UserSkillScore(
                user_id=learner1.id,
                skill_id=skill_map[s_name].id,
                demonstrated_level=lvl,
                status=status,
                evidence_count=ev_count,
                rubric_summary=note,
                last_assessed_at=now - timedelta(days=2)
            )
            db.add(uss)

        # 6. Diagnostic Assessments
        diag_assessment = Assessment(
            title="Senior Full-Stack Diagnostic & Relational Architecture",
            description="Comprehensive practical diagnostic assessing modern TypeScript state machines, relational indexing, execution plans, and OAuth2 security bounds.",
            category="Software Engineering",
            target_role="Senior Full-Stack Engineer",
            difficulty="INTERMEDIATE",
            time_limit_minutes=35,
            passing_score=75.0,
            is_active=True
        )
        db.add(diag_assessment)
        db.flush()

        diag_questions = [
            (
                skill_map["SQL & Query Optimization"].id,
                "In PostgreSQL or relational databases, when an analytical query groups sales by region and calculates running totals with `SUM(sales_amount) OVER (PARTITION BY region_id ORDER BY order_date)`, what index structure most effectively prevents an in-memory disk sort?",
                QuestionType.MCQ,
                [
                    "A single column B-Tree index on (sales_amount)",
                    "A composite B-Tree index on (region_id, order_date) INCLUDE (sales_amount)",
                    "A Hash index on (region_id)",
                    "A GIN index on (order_date)"
                ],
                "A composite B-Tree index on (region_id, order_date) INCLUDE (sales_amount)",
                "A composite index on the partition column and ordering column allows the database engine to scan index tuples directly in sorted sequence without requiring a separate sort step, while INCLUDE avoids heap table fetches.",
                15,
                4
            ),
            (
                skill_map["Frontend Architecture & TypeScript"].id,
                "Which TypeScript design pattern best enforces that an asynchronous UI state machine cannot simultaneously be in a 'loading' and 'error' state?",
                QuestionType.MCQ,
                [
                    "Declaring separate boolean flags: isLoading: boolean, hasError: boolean",
                    "Discriminated union type with a discriminant property (e.g. status: 'idle' | 'loading' | 'success' | 'error')",
                    "Using any type and checking Object.keys() at runtime",
                    "Extending an abstract class with global mutable state"
                ],
                "Discriminated union type with a discriminant property (e.g. status: 'idle' | 'loading' | 'success' | 'error')",
                "Discriminated unions make impossible states unrepresentable in the type system, ensuring exhaustive type checking and preventing UI flag desynchronization.",
                15,
                3
            ),
            (
                skill_map["API Security & Access Control"].id,
                "When implementing JWT-based authentication in modern single-page applications, what is the industry best practice for protecting refresh tokens against Cross-Site Scripting (XSS)?",
                QuestionType.MCQ,
                [
                    "Store the refresh token in localStorage with base64 encoding",
                    "Store the refresh token in an HttpOnly, Secure, SameSite=Strict cookie",
                    "Transmit the refresh token in URL query parameters",
                    "Store the refresh token inside a Redux global store without persistence"
                ],
                "Store the refresh token in an HttpOnly, Secure, SameSite=Strict cookie",
                "HttpOnly cookies cannot be accessed by client-side JavaScript, rendering them immune to extraction via standard XSS payloads, while SameSite provides CSRF mitigation.",
                15,
                3
            ),
            (
                skill_map["Cloud Infrastructure & Containers"].id,
                "What is the key difference between a Kubernetes livenessProbe and a readinessProbe?",
                QuestionType.MCQ,
                [
                    "livenessProbe determines if the container should be restarted; readinessProbe determines if traffic should be routed to the pod",
                    "readinessProbe restarts the container; livenessProbe checks CPU usage",
                    "They are identical and can be used interchangeably",
                    "livenessProbe is used only for database pods; readinessProbe is for web servers"
                ],
                "livenessProbe determines if the container should be restarted; readinessProbe determines if traffic should be routed to the pod",
                "A failing readiness probe removes the pod from the Service endpoints to prevent 502/503 errors during warm-up, while a failing liveness probe triggers container restart.",
                15,
                3
            )
        ]

        for s_id, q_text, q_type, opts, corr_ans, expl, pts, diff in diag_questions:
            aq = AssessmentQuestion(
                assessment_id=diag_assessment.id,
                skill_id=s_id,
                question_text=q_text,
                question_type=q_type,
                options=opts,
                correct_answer=corr_ans,
                explanation=expl,
                points=pts,
                difficulty_level=diff
            )
            db.add(aq)

        # 7. Real-World Missions (Module 2)
        m1 = Mission(
            title="Optimize Degrading SQL Window Analytics for Executive Dashboard",
            description="The executive reporting dashboard is experiencing severe 12-second latency spikes when generating monthly cohort analytics. Refactor the bottleneck SQL query to achieve sub-200ms latency.",
            category="SQL & Database Skills",
            difficulty=MissionDifficulty.INTERMEDIATE,
            estimated_time_minutes=45,
            scenario_context="The corporate billing service contains over 2.4 million transaction records. The current analytics query uses repeated unindexed subqueries and scans full table partitions to calculate monthly active user recurring revenue.",
            instructions="""### Workplace Task Objective
1. Inspect the provided sample dataset schema (`customers`, `subscriptions`, `transactions`).
2. Write a performant SQL query utilizing window functions (`SUM() OVER (...)`, `RANK() OVER (...)` or `LAG()`) to compute monthly running revenue per enterprise customer tier.
3. Filter out cancelled transactions (`status != 'refunded'`).
4. Ensure NULL customer notes default safely using `COALESCE`.
5. Return columns: `customer_tier`, `billing_month`, `monthly_revenue`, `running_cumulative_total`.""",
            sample_data={
                "tables": [
                    {
                        "name": "subscriptions",
                        "columns": ["id (UUID)", "customer_id (UUID)", "customer_tier (VARCHAR)", "monthly_rate (NUMERIC)", "status (VARCHAR)", "created_at (TIMESTAMP)"]
                    },
                    {
                        "name": "transactions",
                        "columns": ["id (UUID)", "subscription_id (UUID)", "amount (NUMERIC)", "status (VARCHAR)", "transaction_date (TIMESTAMP)"]
                    }
                ],
                "sample_rows": [
                    {"customer_tier": "Enterprise", "amount": 12500.00, "status": "completed", "transaction_date": "2026-08-01"},
                    {"customer_tier": "Enterprise", "amount": 15000.00, "status": "completed", "transaction_date": "2026-09-01"},
                    {"customer_tier": "Mid-Market", "amount": 3200.00, "status": "completed", "transaction_date": "2026-09-02"}
                ]
            },
            submission_type="SQL",
            evaluation_rubric=[
                {"criterion": "Window Function Syntax & Partitioning", "max_points": 35, "description": "Accurately applies OVER(PARTITION BY ... ORDER BY ...) to avoid repeated quadratic self-joins."},
                {"criterion": "Execution Efficiency & Filtering", "max_points": 30, "description": "Filters refunded transactions and groups at correct temporal granularity."},
                {"criterion": "Defensive SQL & Edge Handling", "max_points": 20, "description": "Utilizes COALESCE or defensive bounds for zero-transaction months."},
                {"criterion": "Code Formatting & Naming", "max_points": 15, "description": "Clean indentation, clear aliases, and standard SQL keyword conventions."}
            ],
            test_cases=[
                {"name": "Contains Window Function OVER", "type": "contains", "expected_pattern": "over", "description": "Must use analytical OVER clause", "failure_hint": "Analytical window queries require the OVER (...) clause."},
                {"name": "Partitions by Tier or Customer", "type": "contains", "expected_pattern": "partition by", "description": "Must partition by tier or customer ID", "failure_hint": "Ensure you partition cumulative calculations by appropriate entity."},
                {"name": "Filters out refunded transactions", "type": "contains", "expected_pattern": "refunded", "description": "Must account for refunded status", "failure_hint": "Filter condition for non-refunded transactions is required."}
            ],
            required_skills=["SQL & Query Optimization", "Enterprise Data Modeling & ETL"]
        )

        m2 = Mission(
            title="Resolve Critical Production Race Condition in Token Refresh Endpoint",
            description="Audit a multi-threaded FastAPI / Node endpoint where concurrent refresh requests from multiple browser tabs cause token revocation cascades and premature user logouts.",
            category="Software Engineering",
            difficulty=MissionDifficulty.ADVANCED,
            estimated_time_minutes=50,
            scenario_context="Enterprise users with multiple active browser tabs report frequent unexpected session terminations when access tokens expire. Logs reveal that tab A and tab B simultaneously exchange the same single-use refresh token within 15 milliseconds of each other.",
            instructions="""### Workplace Task Objective
1. Identify the concurrency vulnerability in a rotation-based refresh token scheme.
2. Formulate a solution providing either:
   - A short grace period (leeway window) where identical refresh token presentations return the newly issued token pair instead of revoking the family.
   - Or an atomic lock / database transaction with row-level locking (`SELECT ... FOR UPDATE`).
3. Submit your corrected endpoint handler code or architecture specification with explicit error boundaries.""",
            sample_data={
                "endpoint": "POST /api/v1/auth/refresh",
                "payload": {"refresh_token": "rt_98f4e2..."},
                "concurrency_log": [
                    "09:15:02.102 Tab 1 sends rt_98f4e2 -> issued new rt_a71b40",
                    "09:15:02.115 Tab 2 sends rt_98f4e2 -> token reuse detected! Revoked entire token family!"
                ]
            },
            submission_type="CODE",
            evaluation_rubric=[
                {"criterion": "Concurrency Synchronization / Atomic Lock", "max_points": 35, "description": "Correctly prevents duplicate consumption via database transactions, Redis locks, or grace period tokens."},
                {"criterion": "Security & Replay Attack Defense", "max_points": 30, "description": "Retains protection against true malicious replay while allowing valid multi-tab parallel requests."},
                {"criterion": "Error Handling & HTTP Status Standards", "max_points": 20, "description": "Returns appropriate 401 Unauthorized or 409 Conflict headers."},
                {"criterion": "Code Quality & Documentation", "max_points": 15, "description": "Clean typing, structured comments explaining the grace window."}
            ],
            test_cases=[
                {"name": "Handles Grace Window or Lock", "type": "contains", "expected_pattern": "lock", "description": "Mentions or implements locking / concurrency safeguard", "failure_hint": "Implement concurrency locking or a time-bounded grace period."},
                {"name": "Preserves Security Revocation", "type": "contains", "expected_pattern": "token", "description": "Manages token state safely", "failure_hint": "Ensure token state updates atomically."}
            ],
            required_skills=["API Security & Access Control", "Frontend Architecture & TypeScript"]
        )

        m3 = Mission(
            title="Enterprise Incident Post-Mortem & Customer Root Cause Disclosure",
            description="Draft a professional, blameless customer-facing incident post-mortem after a 42-minute multi-tenant database degradation during peak market hours.",
            category="Communication",
            difficulty=MissionDifficulty.INTERMEDIATE,
            estimated_time_minutes=40,
            scenario_context="At 14:18 UTC, a routine migration script locked the transactions table without a statement timeout, causing connection pool exhaustion across 4 services. The outage affected 3,200 enterprise transactions.",
            instructions="""### Workplace Task Objective
Draft an executive post-mortem adhering to enterprise standards:
1. Incident Summary (Duration, Impact, Detection Time).
2. Root Cause Analysis (Without blaming individual engineers).
3. Immediate Mitigations (How service was restored).
4. Permanent Corrective Actions (Prevent recurrence: query timeouts, staged canary deploys, automated migration guards).
5. Transparency & SLA Credit Commitment.""",
            sample_data={
                "incident_id": "INC-2026-8841",
                "duration": "42 minutes",
                "affected_tenants": 412,
                "impact_type": "504 Gateway Timeouts on checkout pipeline"
            },
            submission_type="TEXT",
            evaluation_rubric=[
                {"criterion": "Blameless Engineering Culture", "max_points": 30, "description": "Focuses on systemic process safeguards, test gaps, and automation rather than individual culpability."},
                {"criterion": "Clarity & Executive Professionalism", "max_points": 25, "description": "Concise, precise timeline with unambiguous metrics."},
                {"criterion": "Actionable Preventive Roadmap", "max_points": 30, "description": "Proposes verifiable technical fixes (e.g. pg_stat_activity timeouts, CI migration linters)."},
                {"criterion": "SLA & Customer Empathy", "max_points": 15, "description": "Addresses trust deficit transparently and outlines remediation steps."}
            ],
            test_cases=[
                {"name": "Identifies Root Cause Systemically", "type": "contains", "expected_pattern": "migration", "description": "References database migration lock", "failure_hint": "Address the migration lock as the direct trigger."},
                {"name": "Specifies Corrective Actions", "type": "contains", "expected_pattern": "timeout", "description": "Mentions statement timeout or preventive guard", "failure_hint": "Propose concrete preventive controls such as statement timeouts."}
            ],
            required_skills=["Cross-Functional Stakeholder Alignment", "Consequence-Driven Incident Management"]
        )

        db.add_all([m1, m2, m3])
        db.flush()
        print("Created 3 Real-World Demonstration Missions")

        # Seed sample submission for Alex Rivera
        sub1 = MissionSubmission(
            mission_id=m1.id,
            user_id=learner1.id,
            submission_content="""-- Optimized Window Function Revenue Aggregation
WITH monthly_metrics AS (
    SELECT 
        s.customer_tier,
        DATE_TRUNC('month', t.transaction_date) AS billing_month,
        SUM(COALESCE(t.amount, 0)) AS monthly_revenue
    FROM subscriptions s
    INNER JOIN transactions t ON s.id = t.subscription_id
    WHERE t.status != 'refunded'
    GROUP BY s.customer_tier, DATE_TRUNC('month', t.transaction_date)
)
SELECT 
    customer_tier,
    billing_month,
    monthly_revenue,
    SUM(monthly_revenue) OVER (
        PARTITION BY customer_tier 
        ORDER BY billing_month 
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS running_cumulative_total
FROM monthly_metrics
ORDER BY customer_tier, billing_month;""",
            status=SubmissionStatus.PASSED,
            score=94.5,
            feedback="Exceptional query structure! Leveraged a modular CTE with DATE_TRUNC, filtered refunded transactions early, and correctly partitioned the window running total by tier.",
            rubric_breakdown=[
                {"criterion": "Window Function Syntax & Partitioning", "max_points": 35, "points_awarded": 35, "notes": "Flawless window boundary specifications."},
                {"criterion": "Execution Efficiency & Filtering", "max_points": 30, "points_awarded": 28, "notes": "Early filtering prevents unnecessary aggregation overhead."},
                {"criterion": "Defensive SQL & Edge Handling", "max_points": 20, "points_awarded": 18.5, "notes": "COALESCE utilized on transaction amounts."},
                {"criterion": "Code Formatting & Naming", "max_points": 15, "points_awarded": 13, "notes": "Clear aliases and clean indentation."}
            ],
            test_results=[
                {"test_name": "Contains Window Function OVER", "passed": True, "requirement": "Must use analytical OVER clause", "feedback": "Requirement fulfilled."},
                {"test_name": "Partitions by Tier or Customer", "passed": True, "requirement": "Must partition by tier or customer ID", "feedback": "Requirement fulfilled."},
                {"test_name": "Filters out refunded transactions", "passed": True, "requirement": "Must account for refunded status", "feedback": "Requirement fulfilled."}
            ],
            is_ai_generated=False,
            evaluation_engine="deterministic_rule_engine",
            submitted_at=now - timedelta(days=1),
            evaluated_at=now - timedelta(days=1)
        )
        db.add(sub1)

        # 8. Consequence-Based Learning Simulator (Module 4)
        sc1 = Scenario(
            title="Handling High-Stakes Customer Escalation During Outage",
            description="Navigate a severe real-time production outage where a tier-1 enterprise client with contractual financial SLA penalties demands immediate answers while engineering is actively troubleshooting.",
            category="Crisis Management & Communication",
            difficulty="INTERMEDIATE",
            estimated_minutes=20,
            context_background="At 10:14 AM, the primary message broker cluster enters a crash loop. Payment webhooks for your largest retail partner are delayed by 18 minutes. The client VP of Infrastructure calls your team demanding immediate rollback and a public statement.",
            initial_step_key="step_1",
            learning_objectives=[
                "Practice transparent de-escalation without committing to unverified technical guesses",
                "Coordinate engineering triage and customer success updates simultaneously",
                "Balance contract compliance against risk of hasty rollback failures"
            ],
            rubric=[
                {"criterion": "Executive Composure & Empathy", "max_points": 35, "description": "Acknowledges client business impact without panicking or defensiveness."},
                {"criterion": "Risk Management & Triage", "max_points": 35, "description": "Avoids impulsive rollbacks that could corrupt stateful transactions."},
                {"criterion": "Cadence & Communication Transparency", "max_points": 30, "description": "Establishes a predictable 15-minute status checkpoint."}
            ],
            is_active=True
        )
        db.add(sc1)
        db.flush()

        step1 = ScenarioStep(
            scenario_id=sc1.id,
            step_key="step_1",
            prompt="The client VP of Infrastructure joins an emergency bridge: 'Our checkout gateway is backing up and our CEO is on my neck! Are you rolling back the deployment right now, yes or no?'",
            situation_update="Engineers suspect a schema migration deadlock, but rolling back now without draining the in-flight Kafka queues could permanently drop 4,000 credit card authorizations.",
            choices=[
                {
                    "id": "c1_a",
                    "choice_text": "Immediately agree to roll back to placate the client VP.",
                    "consequences_narrative": "You ordered the rollback immediately. The queue drained improperly, causing 3,800 payment transactions to drop into dead-letter state. Reconciliation will take 3 days. Trust drops sharply.",
                    "metrics_delta": {"trust": -25, "risk": 40, "speed": 10},
                    "next_step_key": "step_2_rollback_failure",
                    "score_points": 10,
                    "rationale": "Never commit to a dangerous stateful rollback without verifying data integrity implications."
                },
                {
                    "id": "c1_b",
                    "choice_text": "Acknowledge the severity, explain the queue safety boundary, commit to a 10-minute triage pause before rollback.",
                    "consequences_narrative": "The client VP accepts the rationale: 'Understood, but I need verified facts at 10:25 sharp.' Engineering discovers the issue is a deadlocked index and cancels the blocking lock safely.",
                    "metrics_delta": {"trust": 20, "risk": -15, "speed": 15},
                    "next_step_key": "step_2_managed_recovery",
                    "score_points": 35,
                    "rationale": "High-trust incident commanders acknowledge severity while protecting technical safety rails."
                },
                {
                    "id": "c1_c",
                    "choice_text": "Deflect the question and tell the client VP to submit an official support ticket.",
                    "consequences_narrative": "The client VP hangs up furiously and calls your Chief Commercial Officer. A contractual breach notice is issued.",
                    "metrics_delta": {"trust": -40, "risk": 35, "speed": -20},
                    "next_step_key": "step_2_executive_escalation",
                    "score_points": 0,
                    "rationale": "Bureaucracy during an active tier-1 outage destroys trust and invites legal consequences."
                }
            ]
        )

        step2_good = ScenarioStep(
            scenario_id=sc1.id,
            step_key="step_2_managed_recovery",
            prompt="At 10:24 AM, engineers kill the rogue query lock. Webhook queue processing resumes and latency drops to normal. How do you communicate the resolution?",
            situation_update="All queues are processing without data loss. The client VP is waiting on the bridge for your update.",
            choices=[
                {
                    "id": "c2_a",
                    "choice_text": "Announce resolution, provide verified queue drain metrics, schedule a preliminary RCA briefing for 3:00 PM.",
                    "consequences_narrative": "The client VP expresses gratitude for transparent leadership under pressure. The SLA penalty is waived in exchange for the scheduled post-mortem.",
                    "metrics_delta": {"trust": 30, "risk": -20, "speed": 20},
                    "next_step_key": None,
                    "score_points": 35,
                    "rationale": "Proactive follow-up with concrete metrics turns an operational crisis into a demonstration of reliability."
                },
                {
                    "id": "c2_b",
                    "choice_text": "Say 'It was just a minor database hiccup on your side' to downplay your service's liability.",
                    "consequences_narrative": "The client discovers the true cause on your public status page later. Trust is permanently damaged due to dishonesty.",
                    "metrics_delta": {"trust": -30, "risk": 20, "speed": 5},
                    "next_step_key": None,
                    "score_points": 5,
                    "rationale": "False claims during outages destroy executive credibility instantly."
                }
            ]
        )

        step2_bad = ScenarioStep(
            scenario_id=sc1.id,
            step_key="step_2_rollback_failure",
            prompt="The premature rollback caused 3,800 un-reconciled orders. Finance and Support are overwhelmed with customer support calls. What is your recovery step?",
            situation_update="Transactions are stuck in limbo. Both executive teams are now involved.",
            choices=[
                {
                    "id": "c2_c",
                    "choice_text": "Own the operational error transparently, deploy an automated replay script, and assign dedicated engineering support.",
                    "consequences_narrative": "Damage is contained over 8 hours of reconciliation. The client appreciates the ownership, though confidence is shaken.",
                    "metrics_delta": {"trust": 15, "risk": -10, "speed": 10},
                    "next_step_key": None,
                    "score_points": 20,
                    "rationale": "When a mistake occurs, transparent ownership and structured remediation are the only viable path."
                }
            ]
        )

        step2_esc = ScenarioStep(
            scenario_id=sc1.id,
            step_key="step_2_executive_escalation",
            prompt="Your CEO joins the emergency room demanding an explanation for why the client was stonewalled.",
            situation_update="Crisis leadership failure.",
            choices=[
                {
                    "id": "c2_d",
                    "choice_text": "Apologize to executive leadership, assume responsibility, and pivot to immediate technical resolution.",
                    "consequences_narrative": "Leadership stabilizes the client relationship, but your management competence is marked for mandatory de-escalation coaching.",
                    "metrics_delta": {"trust": 10, "risk": 15, "speed": 5},
                    "next_step_key": None,
                    "score_points": 15,
                    "rationale": "Rebuilding credibility requires total humility and swift course correction."
                }
            ]
        )

        db.add_all([step1, step2_good, step2_bad, step2_esc])

        # Scenario 2: Resolving a contentious team disagreement
        sc2 = Scenario(
            title="Resolving Cross-Functional Architecture & Deadline Disagreement",
            description="The Lead Frontend Engineer and Backend Architect are in an impasse over API contract design with 5 days left until a contractual customer milestone.",
            category="Leadership & Team Dynamics",
            difficulty="INTERMEDIATE",
            estimated_minutes=15,
            context_background="Frontend wants GraphQL or a tailored BFF endpoint for speed; Backend wants to maintain strict RESTful standards to prevent microservice bloat. Arguments are escalating in Slack channels.",
            initial_step_key="step_1",
            learning_objectives=[
                "Facilitate constructive technical dispute resolution",
                "Distinguish core delivery milestones from architectural perfection",
                "Maintain psychological safety while converging on a decisive outcome"
            ],
            rubric=[
                {"criterion": "Impartiality & Facilitation", "max_points": 40, "description": "Focuses on user and deadline outcomes rather than siding with dogma."},
                {"criterion": "Pragmatic Phasing", "max_points": 35, "description": "Separates Phase 1 delivery from Phase 2 architectural consolidation."},
                {"criterion": "Team Morale & Culture", "max_points": 25, "description": "Ensures both leads feel heard and committed to the chosen path."}
            ],
            is_active=True
        )
        db.add(sc2)
        db.flush()

        sc2_step1 = ScenarioStep(
            scenario_id=sc2.id,
            step_key="step_1",
            prompt="During the sprint sync, the Frontend Lead says: 'If we have to make 8 REST calls per dashboard widget, the app will crawl. We won't ship on Friday.' The Backend Lead counters: 'Writing custom endpoints for every view violates our API governance.' How do you intervene?",
            situation_update="Sprint deadline is in 5 business days.",
            choices=[
                {
                    "id": "sc2_c1",
                    "choice_text": "Side with the Backend Lead and tell Frontend to deal with the 8 calls.",
                    "consequences_narrative": "The release ships with unacceptable latency. Customer complaints surge and the Frontend team feels dismissed.",
                    "metrics_delta": {"trust": -20, "risk": 25, "speed": 10},
                    "next_step_key": None,
                    "score_points": 15,
                    "rationale": "Ignoring end-user performance to preserve theoretical architecture dogma harms customer experience."
                },
                {
                    "id": "sc2_c2",
                    "choice_text": "Timebox a 45-minute working session to agree on a lightweight composite endpoint for Phase 1, with a scheduled retrospective for generic BFF design in Phase 2.",
                    "consequences_narrative": "Both leads align quickly on the compromise. The composite endpoint takes 4 hours to build and the Friday milestone ships with 98ms latency.",
                    "metrics_delta": {"trust": 30, "risk": -20, "speed": 25},
                    "next_step_key": None,
                    "score_points": 40,
                    "rationale": "Pragmatic phasing balances customer deadlines with long-term architecture governance."
                }
            ]
        )
        db.add(sc2_step1)

        # Scenario 3: Prioritizing multiple urgent tasks
        sc3 = Scenario(
            title="Prioritizing Competing Executive Fire-Drills Under Pressure",
            description="You are hit with three simultaneous 'P0 urgent' requests from the CEO, the Security Officer, and the Customer Success Lead on the same afternoon.",
            category="Operational Prioritization",
            difficulty="INTERMEDIATE",
            estimated_minutes=15,
            context_background="1) Security found a medium CVE in an internal auth library requiring a patch. 2) The CEO wants a live demo script prepared for an investor call at 4 PM. 3) Support reports a billing calculation glitch affecting 14 enterprise invoices.",
            initial_step_key="step_1",
            learning_objectives=[
                "Apply the Eisenhower / Impact-Urgency matrix under executive pressure",
                "Communicate prioritization transparently to stakeholders without ghosting",
                "Protect team focus from thrashing"
            ],
            rubric=[
                {"criterion": "Impact Prioritization", "max_points": 40, "description": "Prioritizes immediate financial / customer harm above internal optics."},
                {"criterion": "Stakeholder Negotiation", "max_points": 35, "description": "Negotiates realistic delivery windows with executives calmly."},
                {"criterion": "Execution Focus", "max_points": 25, "description": "Delegates effectively without causing developer panic."}
            ],
            is_active=True
        )
        db.add(sc3)
        db.flush()

        sc3_step1 = ScenarioStep(
            scenario_id=sc3.id,
            step_key="step_1",
            prompt="All three stakeholders ping you within 10 minutes. How do you triage the afternoon?",
            situation_update="Team capacity: 3 engineers available.",
            choices=[
                {
                    "id": "sc3_c1",
                    "choice_text": "Assign Engineer 1 to immediately halt the billing error; prepare a polished pre-recorded demo snippet for the CEO by 3 PM; schedule the internal CVE patch for tonight's maintenance window.",
                    "consequences_narrative": "Billing error stopped with zero further erroneous invoices. CEO has a reliable recording. Security patch deploys cleanly overnight. Executive confidence reinforced.",
                    "metrics_delta": {"trust": 35, "risk": -30, "speed": 25},
                    "next_step_key": None,
                    "score_points": 40,
                    "rationale": "Addresses real customer/financial impact first while offering pragmatic solutions for optics and scheduled security."
                },
                {
                    "id": "sc3_c2",
                    "choice_text": "Drop everything to build a custom interactive demo for the CEO because the CEO holds ultimate authority.",
                    "consequences_narrative": "The billing glitch runs rampant for 4 more hours, creating 120 erroneous customer invoices and thousands in refund liabilities.",
                    "metrics_delta": {"trust": -25, "risk": 45, "speed": -10},
                    "next_step_key": None,
                    "score_points": 10,
                    "rationale": "Sycophancy at the expense of core business integrity exposes the company to severe operational failure."
                }
            ]
        )
        db.add(sc3_step1)
        print("Created 3 Branching Consequence Scenarios")

        # 9. Skill Failure Prevention Loop (Module 3)
        # Create reports showing a recurring cluster around SQL Window Functions
        f1 = FailureReport(
            user_id=learner1.id,
            organization_id=org.id,
            skill_id=skill_map["SQL & Query Optimization"].id,
            topic="SQL Window Functions PARTITION BY",
            description="Struggling to calculate cumulative running sum without duplicating grouped totals across tiers.",
            error_snippet="ERROR: column 'subscriptions.customer_tier' must appear in the GROUP BY clause or be used in an aggregate function",
            emotional_blocker="Confused by interplay between GROUP BY and OVER(PARTITION BY)",
            is_anonymous=False,
            created_at=now - timedelta(days=6)
        )

        f2 = FailureReport(
            user_id=learner2.id,
            organization_id=org.id,
            skill_id=skill_map["SQL & Query Optimization"].id,
            topic="SQL Window Functions PARTITION BY",
            description="Window calculation creates duplicate rows and performance drops when ordering across timestamps.",
            error_snippet="Query plan shows disk spill of 140MB on Sort node",
            emotional_blocker="Unsure how to structure composite indexes to avoid disk spill",
            is_anonymous=True,
            created_at=now - timedelta(days=4)
        )

        f3 = FailureReport(
            user_id=learner3.id,
            organization_id=org.id,
            skill_id=skill_map["SQL & Query Optimization"].id,
            topic="SQL Window Functions PARTITION BY",
            description="Syntax error when trying to combine LAG() with conditional partition filter.",
            error_snippet="syntax error at or near 'FILTER'",
            emotional_blocker="Lack of clean mental model for window frame boundaries",
            is_anonymous=False,
            created_at=now - timedelta(days=3)
        )
        db.add_all([f1, f2, f3])
        db.flush()

        # Clustered Pattern
        pat = FailurePattern(
            organization_id=org.id,
            skill_id=skill_map["SQL & Query Optimization"].id,
            topic="SQL Window Functions PARTITION BY",
            cluster_title="Recurring Difficulty: Window Function Frame & Index Alignment",
            report_count=3,
            confidence_score=0.92,
            status="ACTIVE",
            recommended_intervention_type="MICRO_EXERCISE",
            intervention_details={
                "title": "Targeted Micro-Intervention: Mastering SQL Window Frame Boundaries",
                "description": "Targeted 15-minute diagnostic exercise explaining how relational engines sequence GROUP BY before Window Functions, and how to structure composite indexes to avoid sort disk spills.",
                "practice_prompt": "Step 1: Write an aggregation CTE first. Step 2: Apply the window function in an outer query on the pre-aggregated CTE. Step 3: Verify the explain plan.",
                "linked_mission_id": m1.id,
                "refresher_steps": [
                    "1. Review difference between GROUP BY (collapses rows) vs OVER() (retains row identity).",
                    "2. Avoid aggregating raw rows inside the window when a prior grouped summary is required.",
                    "3. Complete the focused micro-assessment.",
                    "4. Validate improvement with Mission Lab #1."
                ]
            },
            detected_at=now - timedelta(days=2)
        )
        db.add(pat)
        db.flush()

        # Seed Intervention tracking with demonstrated measured improvement!
        # Pre-intervention score: 48.0%, Post-intervention score: 94.5% (Delta: +46.5%)
        track1 = InterventionTracking(
            failure_pattern_id=pat.id,
            user_id=learner1.id,
            status=InterventionStatus.COMPLETED,
            pre_intervention_score=48.0,
            post_intervention_score=94.5,
            score_delta=46.5,
            evidence_demonstrated=True,
            learner_feedback="The mental model separating the grouping CTE from the window execution clarified everything. Solved the mission lab on first try with 94.5%!",
            completed_at=now - timedelta(days=1)
        )
        db.add(track1)
        print("Created Skill Failure Prevention Loop Data with Pre/Post Measured Improvement Delta (+46.5%)")

        # 10. Organizational Knowledge Continuity Radar (Module 5)
        # Article 1: High SPOF Risk (Only 1 SME, no backup)
        k1 = KnowledgeArticle(
            organization_id=org.id,
            title="Monthly PCI-DSS Compliance Audit & Ledger Reconciliation Runbook",
            category="Finance & Security SOP",
            summary="Mission-critical regulatory procedure executed monthly to balance merchant ledger settlements and confirm zero compliance audit discrepancies.",
            content="""# Monthly PCI-DSS Compliance Audit & Ledger Reconciliation
## Scope & Urgency
Mandated by Section 10.2 of PCI-DSS 4.0. Failure to execute on the 1st business day of each month incurs monetary penalties and regulatory review.

## Prerequisites
- Vault token with `pci-audit-readonly` policy
- Read-replica access to `billing_ledger_db`

## Step-by-Step Procedure
1. Export transaction settlement checksums:
   ```bash
   python scripts/audit/export_checksums.py --month=PREVIOUS
   ```
2. Verify tokenized card vaults:
   Confirm all primary account numbers (PAN) are tokenized via AWS KMS HSM.
3. Generate difference report:
   Any variance > $0.00 triggers immediate review with Chief Risk Officer.
4. Sign cryptographically and upload to compliance S3 bucket with retention lock.""",
            owner_id=admin_user.id,
            backup_owner_id=None,  # Single Point of Failure!
            primary_skill_id=skill_map["API Security & Access Control"].id,
            related_skills=["Enterprise Data Modeling & ETL", "API Security & Access Control"],
            review_cadence_days=60,
            last_reviewed_at=now - timedelta(days=75),  # Overdue!
            spof_risk_level=SpofRiskLevel.CRITICAL,
            is_verified_procedure=True,
            status="ACTIVE",
            views_count=42
        )

        # Article 2: Medium SPOF Risk (Backup assigned, training in progress)
        k2 = KnowledgeArticle(
            organization_id=org.id,
            title="Production PostgreSQL Failover & Cross-Region Disaster Recovery",
            category="Platform Runbook",
            summary="Emergency failover runbook to promote cross-region replica in AWS us-east-2 during total primary region degradation.",
            content="""# PostgreSQL Disaster Recovery Runbook
## Criteria for Invocation
Invoked when us-east-1 RDS master has been unreachable for > 5 minutes with active network partition.

## Failover Steps
1. Route 53 Health Check Override: Switch DNS alias to point to secondary proxy.
2. Promote Read-Replica:
   ```bash
   aws rds promote-read-replica --db-instance-identifier prod-db-replica-us-east-2
   ```
3. Update connection pool secrets in AWS Secrets Manager.
4. Notify Engineering Director and post to statuspage.io.""",
            owner_id=manager_user.id,
            backup_owner_id=learner3.id,  # Liam is the backup apprentice
            primary_skill_id=skill_map["Cloud Infrastructure & Containers"].id,
            related_skills=["SQL & Query Optimization", "Cloud Infrastructure & Containers"],
            review_cadence_days=90,
            last_reviewed_at=now - timedelta(days=20),
            spof_risk_level=SpofRiskLevel.MEDIUM,
            is_verified_procedure=True,
            status="ACTIVE",
            views_count=88
        )

        # Article 3: Low SPOF Risk (Multiple verified SMEs)
        k3 = KnowledgeArticle(
            organization_id=org.id,
            title="Kubernetes Cluster Zero-Downtime Rolling Upgrade SOP",
            category="Engineering SOP",
            summary="Standard protocol for upgrading EKS control plane and worker nodes with PodDisruptionBudgets active.",
            content="""# Kubernetes Rolling Upgrade Procedure
1. Verify PodDisruptionBudgets allow at least 1 replica of each core service.
2. Upgrade control plane version in Terraform.
3. Drain worker nodes sequentially with 600s grace period.
4. Validate telemetry metrics on Prometheus dashboard.""",
            owner_id=manager_user.id,
            backup_owner_id=learner1.id,
            primary_skill_id=skill_map["Cloud Infrastructure & Containers"].id,
            related_skills=["Cloud Infrastructure & Containers", "System Observability & Telemetry"],
            review_cadence_days=90,
            last_reviewed_at=now - timedelta(days=10),
            spof_risk_level=SpofRiskLevel.LOW,
            is_verified_procedure=True,
            status="ACTIVE",
            views_count=134
        )

        db.add_all([k1, k2, k3])
        db.flush()

        # Cross training assignment
        ct1 = CrossTrainingAssignment(
            organization_id=org.id,
            knowledge_article_id=k2.id,
            primary_expert_id=manager_user.id,
            backup_learner_id=learner3.id,
            target_completion_date=now + timedelta(days=14),
            status=CrossTrainingStatus.IN_PROGRESS,
            verification_notes="Shadowed drill #1 on staging environment. Scheduled live simulated failover drill next Tuesday."
        )

        ct2 = CrossTrainingAssignment(
            organization_id=org.id,
            knowledge_article_id=k3.id,
            primary_expert_id=manager_user.id,
            backup_learner_id=learner1.id,
            target_completion_date=now - timedelta(days=5),
            status=CrossTrainingStatus.VERIFIED,
            verification_notes="Successfully completed production rolling upgrade under supervision. Competence confirmed.",
            verified_at=now - timedelta(days=5)
        )
        db.add_all([ct1, ct2])
        print("Created Organizational Knowledge Continuity Radar Articles & SPOF Cross-Training Data")

        # 11. Evidence-Based Skill Passport (Module 6)
        pass_alex = SkillPassport(
            user_id=learner1.id,
            share_token="alex-rivera-verified-2026",
            is_public=True,
            headline="Full-Stack Engineer & Aspiring Technical Lead",
            summary_bio="Continuous skill development practitioner focused on scalable backend data pipelines, type-safe frontend state, and resilient cloud architecture at Acme Global Technologies.",
            verified_badge=True,
            verification_authority="SkillBridge AI Continuous Evidence Verification Engine"
        )
        db.add(pass_alex)
        db.flush()

        ev1 = PassportEvidence(
            passport_id=pass_alex.id,
            skill_id=skill_map["SQL & Query Optimization"].id,
            evidence_type=EvidenceType.PROJECT_DEMONSTRATED,
            title="Practical Mission Lab: Optimize Degrading SQL Window Analytics",
            description="Refactored 12-second degraded executive query into a sub-200ms CTE window function pipeline. Scored 94.5% on automated criteria.",
            rubric_score=94.5,
            artifact_ref=sub1.id,
            verification_status="VERIFIED",
            tags=["SQL", "Optimization", "Mission Lab"]
        )

        ev2 = PassportEvidence(
            passport_id=pass_alex.id,
            skill_id=skill_map["Frontend Architecture & TypeScript"].id,
            evidence_type=EvidenceType.PLATFORM_ASSESSED,
            title="Diagnostic Assessment: Senior Full-Stack Architecture",
            description="Demonstrated proficiency in discriminated unions, modular state design, and accessible component architectures.",
            rubric_score=92.0,
            artifact_ref=diag_assessment.id,
            verification_status="VERIFIED",
            tags=["TypeScript", "React", "Architecture"]
        )

        ev3 = PassportEvidence(
            passport_id=pass_alex.id,
            skill_id=skill_map["Cloud Infrastructure & Containers"].id,
            evidence_type=EvidenceType.EXTERNALLY_VERIFIED,
            title="Verified Cross-Training: Kubernetes Rolling Upgrade SOP",
            description="Completed institutional shadow rotation under Engineering Director Marcus Brody; verified zero-downtime execution.",
            rubric_score=100.0,
            artifact_ref=ct2.id,
            verification_status="VERIFIED",
            tags=["Kubernetes", "SOP", "Cross-Training"]
        )

        ev4 = PassportEvidence(
            passport_id=pass_alex.id,
            skill_id=skill_map["API Security & Access Control"].id,
            evidence_type=EvidenceType.SELF_REPORTED,
            title="Completed OWASP Top 10 API Security Specialized Workshop",
            description="Self-attested workshop participation covering OAuth2 flows and JWT attack surface mitigation.",
            rubric_score=None,
            artifact_ref="CERT-OWASP-2026-99",
            verification_status="SELF_ATTESTED",
            tags=["Security", "Self-Reported"]
        )

        db.add_all([ev1, ev2, ev3, ev4])

        # Notifications
        n1 = Notification(
            user_id=learner1.id,
            title="Mission Completed & Verified!",
            message="Your submission for 'Optimize Degrading SQL Window Analytics' achieved 94.5% and was added to your Skill Passport.",
            type="SUCCESS",
            link="/passport"
        )
        n2 = Notification(
            user_id=learner1.id,
            title="Targeted Practice Recommended",
            message="Your failure report on Window Functions was addressed by a newly available targeted micro-intervention.",
            type="INTERVENTION",
            link="/failure-prevention"
        )
        db.add_all([n1, n2])

        db.commit()
        print("SkillBridge AI Database Seeding Finished Successfully!")

    except Exception as e:
        db.rollback()
        print(f"Error during seeding: {e}")
        raise e
    finally:
        db.close()

if __name__ == "__main__":
    run_seed()
