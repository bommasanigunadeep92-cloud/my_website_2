from typing import Optional, List, Any
from datetime import datetime
from pydantic import BaseModel, EmailStr
from app.models.enums import UserRole

class OrganizationBase(BaseModel):
    name: str
    slug: str
    domain: Optional[str] = None

class OrganizationResponse(OrganizationBase):
    id: str
    created_at: datetime

    class Config:
        from_attributes = True

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserRegister(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    role: Optional[UserRole] = UserRole.LEARNER
    organization_slug: Optional[str] = "acme-corp"
    department: Optional[str] = "Engineering"
    job_title: Optional[str] = "Associate Specialist"
    target_role: Optional[str] = "Senior Full-Stack Engineer"

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    department: Optional[str] = None
    job_title: Optional[str] = None
    target_role: Optional[str] = None
    avatar_url: Optional[str] = None

class UserResponse(BaseModel):
    id: str
    email: str
    full_name: str
    role: UserRole
    organization_id: Optional[str] = None
    organization_name: Optional[str] = None
    department: Optional[str] = None
    job_title: Optional[str] = None
    target_role: Optional[str] = None
    avatar_url: Optional[str] = None
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

class NotificationResponse(BaseModel):
    id: str
    title: str
    message: str
    type: str
    link: Optional[str] = None
    is_read: bool
    created_at: datetime

    class Config:
        from_attributes = True

class AuditLogResponse(BaseModel):
    id: str
    user_id: Optional[str] = None
    action: str
    resource_type: str
    resource_id: Optional[str] = None
    details: Optional[dict] = None
    created_at: datetime

    class Config:
        from_attributes = True
