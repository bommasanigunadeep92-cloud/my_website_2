from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel
from app.models.enums import SkillDemonstrationLevel

class SkillResponse(BaseModel):
    id: str
    name: str
    category: str
    description: str
    created_at: datetime

    class Config:
        from_attributes = True

class RoleRequirementResponse(BaseModel):
    id: str
    role_title: str
    skill_id: str
    skill_name: Optional[str] = None
    category: Optional[str] = None
    required_level: float
    importance_weight: float

    class Config:
        from_attributes = True

class UserSkillScoreResponse(BaseModel):
    id: str
    skill_id: str
    skill_name: str
    category: str
    demonstrated_level: float  # 0.0 - 5.0
    status: SkillDemonstrationLevel
    evidence_count: int
    rubric_summary: Optional[str] = None
    last_assessed_at: datetime

    class Config:
        from_attributes = True

class SkillGapItem(BaseModel):
    skill_id: str
    skill_name: str
    category: str
    demonstrated_level: float
    required_level: float
    gap: float  # required - demonstrated (0 if demonstrated >= required)
    status: SkillDemonstrationLevel
    evidence_count: int
    importance_weight: float
    reason: str
    recommended_action: str

class SkillGapAnalysisResponse(BaseModel):
    target_role: str
    overall_readiness_pct: float
    total_skills_required: int
    proficient_skills_count: int
    developing_skills_count: int
    missing_evidence_count: int
    strengths: List[SkillGapItem]
    improvement_areas: List[SkillGapItem]
    radar_data: List[Dict[str, Any]]  # [{skill, demonstrated, required, full_mark: 5}]
    comparison_bars: List[Dict[str, Any]]
    recommendations: List[Dict[str, Any]]

class RoadmapMilestoneResponse(BaseModel):
    id: str
    target_role: str
    milestone_order: int
    title: str
    description: str
    target_skill_id: Optional[str] = None
    target_skill_name: Optional[str] = None
    target_level: float
    status: str
    action_type: str
    action_id: Optional[str] = None
    completed_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class LearningResourceResponse(BaseModel):
    id: str
    skill_id: str
    title: str
    category: Optional[str] = None
    resource_type: str
    url: Optional[str] = None
    summary: str
    estimated_minutes: int

    class Config:
        from_attributes = True
