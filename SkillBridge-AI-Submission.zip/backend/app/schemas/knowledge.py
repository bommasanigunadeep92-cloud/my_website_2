from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel
from app.models.enums import SpofRiskLevel, CrossTrainingStatus

class KnowledgeArticleCreate(BaseModel):
    title: str
    category: str
    summary: str
    content: str
    owner_id: Optional[str] = None
    backup_owner_id: Optional[str] = None
    primary_skill_id: Optional[str] = None
    related_skills: Optional[List[str]] = None
    review_cadence_days: Optional[int] = 90

class KnowledgeArticleUpdate(BaseModel):
    title: Optional[str] = None
    category: Optional[str] = None
    summary: Optional[str] = None
    content: Optional[str] = None
    backup_owner_id: Optional[str] = None
    review_cadence_days: Optional[int] = None
    spof_risk_level: Optional[SpofRiskLevel] = None

class KnowledgeArticleResponse(BaseModel):
    id: str
    organization_id: str
    title: str
    category: str
    summary: str
    content: str
    owner_id: Optional[str] = None
    owner_name: Optional[str] = None
    backup_owner_id: Optional[str] = None
    backup_owner_name: Optional[str] = None
    primary_skill_id: Optional[str] = None
    primary_skill_name: Optional[str] = None
    related_skills: Optional[List[str]] = None
    review_cadence_days: int
    last_reviewed_at: datetime
    next_review_at: Optional[datetime] = None
    spof_risk_level: SpofRiskLevel
    is_verified_procedure: bool
    status: str
    views_count: int
    created_at: datetime

    class Config:
        from_attributes = True

class CrossTrainingCreate(BaseModel):
    knowledge_article_id: str
    backup_learner_id: str
    target_completion_date: Optional[datetime] = None

class CrossTrainingResponse(BaseModel):
    id: str
    organization_id: str
    knowledge_article_id: str
    knowledge_article_title: Optional[str] = None
    primary_expert_id: str
    primary_expert_name: Optional[str] = None
    backup_learner_id: str
    backup_learner_name: Optional[str] = None
    target_completion_date: Optional[datetime] = None
    status: CrossTrainingStatus
    verification_notes: Optional[str] = None
    verified_at: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True

class KnowledgeRadarAnalyticsResponse(BaseModel):
    total_articles: int
    overall_coverage_health_pct: float
    critical_spof_count: int
    high_spof_count: int
    medium_spof_count: int
    low_spof_count: int
    outdated_review_count: int
    active_cross_trainings_count: int
    spof_alerts: List[Dict[str, Any]]
    category_distribution: List[Dict[str, Any]]
    recommendations: List[Dict[str, Any]]
