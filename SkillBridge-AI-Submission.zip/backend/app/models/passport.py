from datetime import datetime, timezone
import uuid
from sqlalchemy import Column, String, Float, Boolean, ForeignKey, Text, Enum, DateTime, JSON
from sqlalchemy.orm import relationship
from app.core.database import Base
from app.models.enums import EvidenceType

def generate_uuid():
    return str(uuid.uuid4())

def generate_share_token():
    return uuid.uuid4().hex[:16]

class SkillPassport(Base):
    __tablename__ = "skill_passports"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True, index=True)
    share_token = Column(String(64), default=generate_share_token, unique=True, index=True)
    is_public = Column(Boolean, default=True)
    headline = Column(String(200), default="Certified Corporate Practitioner")
    summary_bio = Column(Text, nullable=True)
    verified_badge = Column(Boolean, default=True)
    verification_authority = Column(String(200), default="SkillBridge AI Verification Engine")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    user = relationship("User", back_populates="passport")
    evidence_items = relationship("PassportEvidence", back_populates="passport", cascade="all, delete-orphan")


class PassportEvidence(Base):
    __tablename__ = "passport_evidence"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    passport_id = Column(String(36), ForeignKey("skill_passports.id", ondelete="CASCADE"), nullable=False, index=True)
    skill_id = Column(String(36), ForeignKey("skills.id", ondelete="CASCADE"), nullable=False, index=True)
    evidence_type = Column(Enum(EvidenceType), default=EvidenceType.PROJECT_DEMONSTRATED, nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    rubric_score = Column(Float, nullable=True)  # e.g. 94.5%
    artifact_ref = Column(String(255), nullable=True)  # submission ID or assessment ID
    verification_status = Column(String(50), default="VERIFIED")  # VERIFIED, SELF_ATTESTED, PENDING
    verified_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    tags = Column(JSON, nullable=True, default=list)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    passport = relationship("SkillPassport", back_populates="evidence_items")
    skill = relationship("Skill")
