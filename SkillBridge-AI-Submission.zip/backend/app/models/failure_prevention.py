from datetime import datetime, timezone
import uuid
from sqlalchemy import Column, String, Float, Integer, Boolean, ForeignKey, Text, Enum, DateTime, JSON
from sqlalchemy.orm import relationship
from app.core.database import Base
from app.models.enums import InterventionStatus

def generate_uuid():
    return str(uuid.uuid4())

class FailureReport(Base):
    __tablename__ = "failure_reports"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    organization_id = Column(String(36), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    skill_id = Column(String(36), ForeignKey("skills.id", ondelete="CASCADE"), nullable=False, index=True)
    topic = Column(String(200), nullable=False, index=True)
    description = Column(Text, nullable=False)
    error_snippet = Column(Text, nullable=True)
    emotional_blocker = Column(String(100), nullable=True)
    is_anonymous = Column(Boolean, default=False)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    user = relationship("User")
    skill = relationship("Skill")


class FailurePattern(Base):
    __tablename__ = "failure_patterns"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    organization_id = Column(String(36), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    skill_id = Column(String(36), ForeignKey("skills.id", ondelete="CASCADE"), nullable=False, index=True)
    topic = Column(String(200), nullable=False)
    cluster_title = Column(String(255), nullable=False)
    report_count = Column(Integer, default=1)
    confidence_score = Column(Float, default=0.85)  # 0.0 to 1.0
    status = Column(String(50), default="ACTIVE")  # ACTIVE, RESOLVED
    recommended_intervention_type = Column(String(100), default="MICRO_EXERCISE")  # MICRO_EXERCISE, REFRESHER_GUIDE, TARGETED_MISSION
    intervention_details = Column(JSON, nullable=False)  # {title, description, practice_prompt, linked_mission_id, tips}
    detected_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    resolved_at = Column(DateTime, nullable=True)

    skill = relationship("Skill")
    interventions = relationship("InterventionTracking", back_populates="failure_pattern", cascade="all, delete-orphan")


class InterventionTracking(Base):
    __tablename__ = "intervention_trackings"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    failure_pattern_id = Column(String(36), ForeignKey("failure_patterns.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    status = Column(Enum(InterventionStatus), default=InterventionStatus.ASSIGNED, nullable=False)
    pre_intervention_score = Column(Float, nullable=True)  # Diagnostic or mission score before
    post_intervention_score = Column(Float, nullable=True)  # Score after completing practice
    score_delta = Column(Float, nullable=True)
    evidence_demonstrated = Column(Boolean, default=False)
    learner_feedback = Column(Text, nullable=True)
    completed_at = Column(DateTime, nullable=True)

    failure_pattern = relationship("FailurePattern", back_populates="interventions")
    user = relationship("User")
