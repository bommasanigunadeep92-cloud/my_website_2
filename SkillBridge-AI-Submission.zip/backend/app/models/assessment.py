from datetime import datetime, timezone
import uuid
from sqlalchemy import Column, String, Float, Integer, Boolean, ForeignKey, Text, Enum, DateTime, JSON
from sqlalchemy.orm import relationship
from app.core.database import Base
from app.models.enums import QuestionType

def generate_uuid():
    return str(uuid.uuid4())

class Assessment(Base):
    __tablename__ = "assessments"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(String(100), nullable=False, index=True)
    target_role = Column(String(150), nullable=True, index=True)
    difficulty = Column(String(50), default="INTERMEDIATE")  # BEGINNER, INTERMEDIATE, ADVANCED
    time_limit_minutes = Column(Integer, default=30)
    passing_score = Column(Float, default=70.0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    questions = relationship("AssessmentQuestion", back_populates="assessment", cascade="all, delete-orphan")
    attempts = relationship("AssessmentAttempt", back_populates="assessment", cascade="all, delete-orphan")


class AssessmentQuestion(Base):
    __tablename__ = "assessment_questions"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    assessment_id = Column(String(36), ForeignKey("assessments.id", ondelete="CASCADE"), nullable=False, index=True)
    skill_id = Column(String(36), ForeignKey("skills.id", ondelete="CASCADE"), nullable=False, index=True)
    question_text = Column(Text, nullable=False)
    question_type = Column(Enum(QuestionType), default=QuestionType.MCQ, nullable=False)
    options = Column(JSON, nullable=True)  # List of strings for MCQ
    correct_answer = Column(Text, nullable=False)  # Exact choice or expected string or regex
    explanation = Column(Text, nullable=False)
    rubric = Column(JSON, nullable=True)  # Detailed criteria for scoring
    points = Column(Integer, default=10)
    difficulty_level = Column(Integer, default=3)  # 1 to 5

    assessment = relationship("Assessment", back_populates="questions")
    skill = relationship("Skill", back_populates="assessment_questions")


class AssessmentAttempt(Base):
    __tablename__ = "assessment_attempts"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    assessment_id = Column(String(36), ForeignKey("assessments.id", ondelete="CASCADE"), nullable=False, index=True)
    score = Column(Float, nullable=False, default=0.0)  # 0 to 100 percentage
    passed = Column(Boolean, default=False)
    started_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, nullable=True)
    answers = Column(JSON, nullable=True, default=dict)  # question_id -> user_answer
    evaluation_detail = Column(JSON, nullable=True, default=dict)  # per-question scores, rubrics, skill changes
    feedback_notes = Column(Text, nullable=True)
    is_ai_generated = Column(Boolean, default=False)

    user = relationship("User", back_populates="assessment_attempts")
    assessment = relationship("Assessment", back_populates="attempts")
