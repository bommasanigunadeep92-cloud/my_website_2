from datetime import datetime, timezone
import uuid
from sqlalchemy import Column, String, Integer, Boolean, ForeignKey, Text, Enum, DateTime, JSON
from sqlalchemy.orm import relationship
from app.core.database import Base
from app.models.enums import SpofRiskLevel, CrossTrainingStatus

def generate_uuid():
    return str(uuid.uuid4())

class KnowledgeArticle(Base):
    __tablename__ = "knowledge_articles"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    organization_id = Column(String(36), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    category = Column(String(100), nullable=False, index=True)  # Operations, Engineering SOP, Incident Response, Finance & Reporting, Data Architecture
    summary = Column(Text, nullable=False)
    content = Column(Text, nullable=False)
    owner_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    backup_owner_id = Column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    primary_skill_id = Column(String(36), ForeignKey("skills.id", ondelete="SET NULL"), nullable=True, index=True)
    related_skills = Column(JSON, nullable=True, default=list)
    review_cadence_days = Column(Integer, default=90)
    last_reviewed_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    next_review_at = Column(DateTime, nullable=True)
    spof_risk_level = Column(Enum(SpofRiskLevel), default=SpofRiskLevel.MEDIUM, nullable=False)
    is_verified_procedure = Column(Boolean, default=True)
    status = Column(String(50), default="ACTIVE")
    views_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    organization = relationship("Organization", back_populates="knowledge_articles")
    owner = relationship("User", foreign_keys=[owner_id])
    backup_owner = relationship("User", foreign_keys=[backup_owner_id])
    primary_skill = relationship("Skill", back_populates="knowledge_articles")
    cross_trainings = relationship("CrossTrainingAssignment", back_populates="knowledge_article", cascade="all, delete-orphan")


class CrossTrainingAssignment(Base):
    __tablename__ = "cross_training_assignments"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    organization_id = Column(String(36), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    knowledge_article_id = Column(String(36), ForeignKey("knowledge_articles.id", ondelete="CASCADE"), nullable=False, index=True)
    primary_expert_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    backup_learner_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    target_completion_date = Column(DateTime, nullable=True)
    status = Column(Enum(CrossTrainingStatus), default=CrossTrainingStatus.ASSIGNED, nullable=False)
    verification_notes = Column(Text, nullable=True)
    verified_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    knowledge_article = relationship("KnowledgeArticle", back_populates="cross_trainings")
    primary_expert = relationship("User", foreign_keys=[primary_expert_id])
    backup_learner = relationship("User", foreign_keys=[backup_learner_id])
