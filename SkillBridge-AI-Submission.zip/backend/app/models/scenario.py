from datetime import datetime, timezone
import uuid
from sqlalchemy import Column, String, Float, Integer, Boolean, ForeignKey, Text, DateTime, JSON
from sqlalchemy.orm import relationship
from app.core.database import Base

def generate_uuid():
    return str(uuid.uuid4())

class Scenario(Base):
    __tablename__ = "scenarios"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(String(100), nullable=False, index=True)
    difficulty = Column(String(50), default="INTERMEDIATE")
    estimated_minutes = Column(Integer, default=20)
    context_background = Column(Text, nullable=False)
    initial_step_key = Column(String(50), default="step_1", nullable=False)
    learning_objectives = Column(JSON, nullable=False, default=list)
    rubric = Column(JSON, nullable=False, default=list)  # criteria, max points, guidance
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    steps = relationship("ScenarioStep", back_populates="scenario", cascade="all, delete-orphan")
    attempts = relationship("ScenarioAttempt", back_populates="scenario", cascade="all, delete-orphan")


class ScenarioStep(Base):
    __tablename__ = "scenario_steps"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    scenario_id = Column(String(36), ForeignKey("scenarios.id", ondelete="CASCADE"), nullable=False, index=True)
    step_key = Column(String(50), nullable=False, index=True)
    prompt = Column(Text, nullable=False)
    situation_update = Column(Text, nullable=True)
    choices = Column(JSON, nullable=False)  # list of choices with next_step, consequences, score, metrics_delta, rationale

    scenario = relationship("Scenario", back_populates="steps")


class ScenarioAttempt(Base):
    __tablename__ = "scenario_attempts"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    scenario_id = Column(String(36), ForeignKey("scenarios.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    steps_history = Column(JSON, nullable=False, default=list)
    total_score = Column(Float, default=0.0)
    performance_rating = Column(String(100), default="COMPLETED")
    debrief_notes = Column(Text, nullable=True)
    metrics_summary = Column(JSON, nullable=True, default=dict)
    is_ai_generated = Column(Boolean, default=False)
    completed_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    scenario = relationship("Scenario", back_populates="attempts")
    user = relationship("User", back_populates="scenario_attempts")
