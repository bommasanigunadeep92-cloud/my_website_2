from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.routers.auth import get_current_user
from app.models.user import User, AuditLog
from app.models.assessment import Assessment, AssessmentQuestion, AssessmentAttempt
from app.models.passport import SkillPassport, PassportEvidence
from app.models.enums import EvidenceType, QuestionType
from app.schemas.assessment import (
    AssessmentListResponse,
    AssessmentDetailResponse,
    AssessmentQuestionResponse,
    AssessmentSubmitRequest,
    AssessmentAttemptResponse
)
from app.services.scoring_service import scoring_service

router = APIRouter(prefix="/assessments", tags=["Diagnostic Assessments"])

@router.get("", response_model=List[AssessmentListResponse])
def list_assessments(
    category: Optional[str] = None,
    target_role: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Assessment).filter(Assessment.is_active == True)
    if category:
        query = query.filter(Assessment.category == category)
    if target_role:
        query = query.filter(Assessment.target_role.ilike(f"%{target_role}%"))
    
    assessments = query.all()
    results = []
    for a in assessments:
        results.append(AssessmentListResponse(
            id=a.id,
            title=a.title,
            description=a.description,
            category=a.category,
            target_role=a.target_role,
            difficulty=a.difficulty,
            time_limit_minutes=a.time_limit_minutes,
            passing_score=a.passing_score,
            question_count=len(a.questions)
        ))
    return results

@router.get("/{assessment_id}", response_model=AssessmentDetailResponse)
def get_assessment(
    assessment_id: str,
    db: Session = Depends(get_db)
):
    a = db.query(Assessment).filter(Assessment.id == assessment_id).first()
    if not a:
        raise HTTPException(status_code=404, detail="Assessment not found")

    questions_resp = []
    for q in a.questions:
        questions_resp.append(AssessmentQuestionResponse(
            id=q.id,
            skill_id=q.skill_id,
            skill_name=q.skill.name if q.skill else None,
            question_text=q.question_text,
            question_type=q.question_type,
            options=q.options,
            points=q.points,
            difficulty_level=q.difficulty_level
        ))

    return AssessmentDetailResponse(
        id=a.id,
        title=a.title,
        description=a.description,
        category=a.category,
        target_role=a.target_role,
        difficulty=a.difficulty,
        time_limit_minutes=a.time_limit_minutes,
        passing_score=a.passing_score,
        question_count=len(a.questions),
        questions=questions_resp
    )

@router.post("/{assessment_id}/submit", response_model=AssessmentAttemptResponse)
def submit_assessment(
    assessment_id: str,
    payload: AssessmentSubmitRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    assessment = db.query(Assessment).filter(Assessment.id == assessment_id).first()
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    questions = assessment.questions
    if not questions:
        raise HTTPException(status_code=400, detail="Assessment contains no questions")

    total_possible = sum(q.points for q in questions)
    awarded_points = 0
    question_breakdown = []
    skill_points: Dict[str, Dict[str, float]] = {}  # skill_id -> {awarded, possible}

    for q in questions:
        user_ans = payload.answers.get(q.id, "").strip()
        correct_ans = q.correct_answer.strip()
        is_correct = False

        if q.question_type == QuestionType.MCQ:
            is_correct = user_ans.lower() == correct_ans.lower()
        else:
            # Deterministic semantic check for short-answer or practical SQL/code
            clean_user = user_ans.lower().replace(";", "").replace("  ", " ")
            clean_correct = correct_ans.lower().replace(";", "").replace("  ", " ")
            is_correct = (clean_user == clean_correct) or (clean_correct in clean_user)

        pts = q.points if is_correct else 0
        awarded_points += pts

        # Track per skill
        if q.skill_id not in skill_points:
            skill_points[q.skill_id] = {"awarded": 0.0, "possible": 0.0}
        skill_points[q.skill_id]["awarded"] += pts
        skill_points[q.skill_id]["possible"] += q.points

        question_breakdown.append({
            "question_id": q.id,
            "question_text": q.question_text,
            "user_answer": user_ans,
            "correct_answer": correct_ans,
            "is_correct": is_correct,
            "points_awarded": pts,
            "max_points": q.points,
            "explanation": q.explanation
        })

    score_pct = round((awarded_points / total_possible * 100), 1) if total_possible > 0 else 0.0
    passed = score_pct >= assessment.passing_score

    # Update skill scores for user
    skill_updates = []
    for s_id, s_data in skill_points.items():
        s_pct = (s_data["awarded"] / s_data["possible"] * 100) if s_data["possible"] > 0 else score_pct
        updated_score = scoring_service.update_user_skill_from_assessment(
            db=db,
            user_id=current_user.id,
            skill_id=s_id,
            assessment_score_pct=s_pct,
            rubric_note=f"Assessment '{assessment.title}'"
        )
        skill_updates.append({
            "skill_id": s_id,
            "skill_name": updated_score.skill.name,
            "new_level": updated_score.demonstrated_level,
            "status": updated_score.status.value
        })

    # Record Attempt
    attempt = AssessmentAttempt(
        user_id=current_user.id,
        assessment_id=assessment.id,
        score=score_pct,
        passed=passed,
        started_at=datetime.now(timezone.utc),
        completed_at=datetime.now(timezone.utc),
        answers=payload.answers,
        evaluation_detail={"questions": question_breakdown, "skill_updates": skill_updates},
        feedback_notes=(
            f"Completed assessment '{assessment.title}' with {score_pct}%. "
            f"{'Passed benchmark requirement.' if passed else 'Did not meet passing score of ' + str(assessment.passing_score) + '%. Review highlighted explanations and retry.'}"
        ),
        is_ai_generated=False
    )
    db.add(attempt)

    # If passed, register in Skill Passport evidence
    if passed:
        passport = db.query(SkillPassport).filter(SkillPassport.user_id == current_user.id).first()
        if passport:
            # Add evidence item for primary skill
            primary_skill_id = questions[0].skill_id if questions else None
            if primary_skill_id:
                ev = PassportEvidence(
                    passport_id=passport.id,
                    skill_id=primary_skill_id,
                    evidence_type=EvidenceType.PLATFORM_ASSESSED,
                    title=f"Diagnostic Assessment: {assessment.title}",
                    description=f"Demonstrated verified proficiency with a score of {score_pct}%.",
                    rubric_score=score_pct,
                    artifact_ref=attempt.id,
                    verification_status="VERIFIED"
                )
                db.add(ev)

    # Audit log
    audit = AuditLog(
        organization_id=current_user.organization_id,
        user_id=current_user.id,
        action="ASSESSMENT_COMPLETED",
        resource_type="ASSESSMENT",
        resource_id=assessment.id,
        details={"score": score_pct, "passed": passed}
    )
    db.add(audit)
    db.commit()
    db.refresh(attempt)

    return AssessmentAttemptResponse(
        id=attempt.id,
        assessment_id=attempt.assessment_id,
        assessment_title=assessment.title,
        user_id=attempt.user_id,
        score=attempt.score,
        passed=attempt.passed,
        started_at=attempt.started_at,
        completed_at=attempt.completed_at,
        evaluation_detail=attempt.evaluation_detail,
        feedback_notes=attempt.feedback_notes,
        is_ai_generated=attempt.is_ai_generated,
        skill_updates=skill_updates
    )

@router.get("/history/me", response_model=List[AssessmentAttemptResponse])
def get_user_assessment_history(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    attempts = db.query(AssessmentAttempt).filter(
        AssessmentAttempt.user_id == current_user.id
    ).order_by(AssessmentAttempt.completed_at.desc()).all()

    res = []
    for a in attempts:
        res.append(AssessmentAttemptResponse(
            id=a.id,
            assessment_id=a.assessment_id,
            assessment_title=a.assessment.title if a.assessment else "Assessment",
            user_id=a.user_id,
            score=a.score,
            passed=a.passed,
            started_at=a.started_at,
            completed_at=a.completed_at,
            evaluation_detail=a.evaluation_detail,
            feedback_notes=a.feedback_notes,
            is_ai_generated=a.is_ai_generated
        ))
    return res
