from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.routers.auth import get_current_user
from app.models.user import User, AuditLog
from app.models.passport import SkillPassport, PassportEvidence
from app.models.skill import Skill
from app.models.enums import EvidenceType
from app.schemas.passport import (
    SkillPassportResponse,
    PassportEvidenceResponse,
    PassportEvidenceCreate,
    ShareSettingsUpdate
)
from app.services.scoring_service import scoring_service

router = APIRouter(prefix="/passport", tags=["Evidence-Based Skill Passport"])

def format_passport_response(passport: SkillPassport, db: Session) -> SkillPassportResponse:
    user = passport.user
    org_name = user.organization.name if user.organization else None

    # Calculate metrics
    evidence_items = []
    assessed_count = 0
    projects_count = 0

    for ev in passport.evidence_items:
        skill = ev.skill
        if ev.evidence_type == EvidenceType.PLATFORM_ASSESSED:
            assessed_count += 1
        elif ev.evidence_type == EvidenceType.PROJECT_DEMONSTRATED:
            projects_count += 1

        evidence_items.append(PassportEvidenceResponse(
            id=ev.id,
            passport_id=ev.passport_id,
            skill_id=ev.skill_id,
            skill_name=skill.name if skill else "Skill",
            skill_category=skill.category if skill else "General",
            evidence_type=ev.evidence_type,
            title=ev.title,
            description=ev.description,
            rubric_score=ev.rubric_score,
            artifact_ref=ev.artifact_ref,
            verification_status=ev.verification_status,
            verified_at=ev.verified_at,
            tags=ev.tags or [],
            created_at=ev.created_at
        ))

    # Readiness score from scoring service
    gap_data = scoring_service.calculate_skill_gap_analysis(
        db=db,
        user_id=user.id,
        target_role=user.target_role or "Senior Full-Stack Engineer",
        org_id=user.organization_id
    )

    return SkillPassportResponse(
        id=passport.id,
        user_id=user.id,
        user_name=user.full_name,
        user_email=user.email,
        organization_name=org_name,
        department=user.department,
        job_title=user.job_title,
        target_role=user.target_role,
        share_token=passport.share_token,
        is_public=passport.is_public,
        headline=passport.headline or f"{user.job_title} | SkillBridge Verified Practitioner",
        summary_bio=passport.summary_bio or f"Continuous skill practitioner at {org_name or 'SkillBridge Network'}.",
        verified_badge=passport.verified_badge,
        verification_authority=passport.verification_authority,
        created_at=passport.created_at,
        updated_at=passport.updated_at,
        evidence_items=evidence_items,
        assessed_skills_count=assessed_count,
        projects_verified_count=projects_count,
        readiness_score=gap_data.get("overall_readiness_pct", 75.0)
    )

@router.get("/me", response_model=SkillPassportResponse)
def get_my_passport(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    passport = db.query(SkillPassport).filter(SkillPassport.user_id == current_user.id).first()
    if not passport:
        passport = SkillPassport(
            user_id=current_user.id,
            headline=f"{current_user.job_title} | Practitioner",
            summary_bio=f"Continuous corporate learning record.",
            verified_badge=True
        )
        db.add(passport)
        db.commit()
        db.refresh(passport)

    return format_passport_response(passport, db)

@router.put("/settings", response_model=SkillPassportResponse)
def update_passport_settings(
    payload: ShareSettingsUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    passport = db.query(SkillPassport).filter(SkillPassport.user_id == current_user.id).first()
    if not passport:
        raise HTTPException(status_code=404, detail="Passport not found")

    if payload.is_public is not None:
        passport.is_public = payload.is_public
    if payload.headline is not None:
        passport.headline = payload.headline
    if payload.summary_bio is not None:
        passport.summary_bio = payload.summary_bio
    if payload.generate_new_token:
        passport.share_token = uuid.uuid4().hex[:16]

    passport.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(passport)

    return format_passport_response(passport, db)

@router.post("/evidence", response_model=PassportEvidenceResponse)
def add_custom_evidence(
    payload: PassportEvidenceCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    passport = db.query(SkillPassport).filter(SkillPassport.user_id == current_user.id).first()
    if not passport:
        raise HTTPException(status_code=404, detail="Passport not found")

    skill = db.query(Skill).filter(Skill.id == payload.skill_id).first()
    if not skill:
        raise HTTPException(status_code=404, detail="Skill not found")

    # Mark non-platform evidence as self-attested or pending review
    v_status = "VERIFIED" if payload.evidence_type in [EvidenceType.PLATFORM_ASSESSED, EvidenceType.PROJECT_DEMONSTRATED] else "SELF_ATTESTED"

    ev = PassportEvidence(
        passport_id=passport.id,
        skill_id=skill.id,
        evidence_type=payload.evidence_type,
        title=payload.title,
        description=payload.description,
        rubric_score=payload.rubric_score,
        artifact_ref=payload.artifact_ref,
        verification_status=v_status,
        tags=payload.tags or ["Self-Reported"],
        verified_at=datetime.now(timezone.utc)
    )
    db.add(ev)
    db.commit()
    db.refresh(ev)

    return PassportEvidenceResponse(
        id=ev.id,
        passport_id=ev.passport_id,
        skill_id=ev.skill_id,
        skill_name=skill.name,
        skill_category=skill.category,
        evidence_type=ev.evidence_type,
        title=ev.title,
        description=ev.description,
        rubric_score=ev.rubric_score,
        artifact_ref=ev.artifact_ref,
        verification_status=ev.verification_status,
        verified_at=ev.verified_at,
        tags=ev.tags or [],
        created_at=ev.created_at
    )

@router.get("/public/{share_token}", response_model=SkillPassportResponse)
def get_public_passport(share_token: str, db: Session = Depends(get_db)):
    """
    Publicly accessible endpoint (no auth required) using a unique, revocable share token.
    Enforces privacy: if is_public is False, denies access.
    """
    passport = db.query(SkillPassport).filter(SkillPassport.share_token == share_token).first()
    if not passport or not passport.is_public:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Skill Passport is private or the share link has been revoked."
        )

    return format_passport_response(passport, db)
