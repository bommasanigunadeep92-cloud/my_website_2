from datetime import timedelta, datetime, timezone
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.core.security import get_password_hash, verify_password, create_access_token, decode_access_token, oauth2_scheme
from app.models.user import User, Organization, AuditLog
from app.models.passport import SkillPassport
from app.models.enums import UserRole
from app.schemas.user import UserLogin, UserRegister, UserResponse, UserUpdate, TokenResponse

router = APIRouter(prefix="/auth", tags=["Authentication"])

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    payload = decode_access_token(token)
    user_id: str = payload.get("sub")
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token payload missing subject identifier.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found.")
    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="User account is deactivated.")
    return user

def require_role(allowed_roles: List[UserRole]):
    def role_checker(current_user: User = Depends(get_current_user)):
        if current_user.role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Operation not permitted. Required roles: {[r.value for r in allowed_roles]}"
            )
        return current_user
    return role_checker

@router.post("/register", response_model=TokenResponse)
def register(user_in: UserRegister, db: Session = Depends(get_db)):
    # Check if user already exists
    existing = db.query(User).filter(User.email == user_in.email).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A user with this email address already exists."
        )

    # Find or create organization
    org = db.query(Organization).filter(Organization.slug == user_in.organization_slug).first()
    if not org:
        org = Organization(
            name=user_in.organization_slug.replace("-", " ").title(),
            slug=user_in.organization_slug,
            domain=f"{user_in.organization_slug}.example.com"
        )
        db.add(org)
        db.flush()

    # Create user
    user = User(
        email=user_in.email,
        hashed_password=get_password_hash(user_in.password),
        full_name=user_in.full_name,
        role=user_in.role or UserRole.LEARNER,
        organization_id=org.id,
        department=user_in.department or "Engineering",
        job_title=user_in.job_title or "Associate Practitioner",
        target_role=user_in.target_role or "Senior Full-Stack Engineer"
    )
    db.add(user)
    db.flush()

    # Create associated Skill Passport
    passport = SkillPassport(
        user_id=user.id,
        headline=f"{user.job_title} | Aspirant {user.target_role}",
        summary_bio=f"Continuous corporate learner focusing on practical skill mastery in {user.department}.",
        verified_badge=True
    )
    db.add(passport)

    # Record audit log
    audit = AuditLog(
        organization_id=org.id,
        user_id=user.id,
        action="USER_REGISTRATION",
        resource_type="USER",
        resource_id=user.id,
        details={"email": user.email, "role": user.role.value}
    )
    db.add(audit)
    db.commit()
    db.refresh(user)

    token = create_access_token(
        subject=user.id,
        extra_claims={"email": user.email, "role": user.role.value, "org_id": org.id}
    )

    user_resp = UserResponse(
        id=user.id,
        email=user.email,
        full_name=user.full_name,
        role=user.role,
        organization_id=user.organization_id,
        organization_name=org.name,
        department=user.department,
        job_title=user.job_title,
        target_role=user.target_role,
        avatar_url=user.avatar_url,
        is_active=user.is_active,
        created_at=user.created_at
    )

    return TokenResponse(access_token=token, token_type="bearer", user=user_resp)

@router.post("/login", response_model=TokenResponse)
def login(login_data: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == login_data.email).first()
    if not user or not verify_password(login_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Account is deactivated.")

    token = create_access_token(
        subject=user.id,
        extra_claims={
            "email": user.email,
            "role": user.role.value,
            "org_id": user.organization_id
        }
    )

    org_name = user.organization.name if user.organization else None

    user_resp = UserResponse(
        id=user.id,
        email=user.email,
        full_name=user.full_name,
        role=user.role,
        organization_id=user.organization_id,
        organization_name=org_name,
        department=user.department,
        job_title=user.job_title,
        target_role=user.target_role,
        avatar_url=user.avatar_url,
        is_active=user.is_active,
        created_at=user.created_at
    )

    return TokenResponse(access_token=token, token_type="bearer", user=user_resp)

@router.get("/me", response_model=UserResponse)
def get_me(current_user: User = Depends(get_current_user)):
    org_name = current_user.organization.name if current_user.organization else None
    return UserResponse(
        id=current_user.id,
        email=current_user.email,
        full_name=current_user.full_name,
        role=current_user.role,
        organization_id=current_user.organization_id,
        organization_name=org_name,
        department=current_user.department,
        job_title=current_user.job_title,
        target_role=current_user.target_role,
        avatar_url=current_user.avatar_url,
        is_active=current_user.is_active,
        created_at=current_user.created_at
    )

@router.put("/me", response_model=UserResponse)
def update_me(update_data: UserUpdate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if update_data.full_name is not None:
        current_user.full_name = update_data.full_name
    if update_data.department is not None:
        current_user.department = update_data.department
    if update_data.job_title is not None:
        current_user.job_title = update_data.job_title
    if update_data.target_role is not None:
        current_user.target_role = update_data.target_role
    if update_data.avatar_url is not None:
        current_user.avatar_url = update_data.avatar_url

    db.commit()
    db.refresh(current_user)

    org_name = current_user.organization.name if current_user.organization else None
    return UserResponse(
        id=current_user.id,
        email=current_user.email,
        full_name=current_user.full_name,
        role=current_user.role,
        organization_id=current_user.organization_id,
        organization_name=org_name,
        department=current_user.department,
        job_title=current_user.job_title,
        target_role=current_user.target_role,
        avatar_url=current_user.avatar_url,
        is_active=current_user.is_active,
        created_at=current_user.created_at
    )
