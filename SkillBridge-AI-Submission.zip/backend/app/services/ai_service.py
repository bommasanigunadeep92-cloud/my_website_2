import os
import json
import logging
from typing import Dict, Any, List, Optional
import httpx
from app.core.config import settings

logger = logging.getLogger(__name__)

class AIService:
    """
    Provider-independent AI service with robust deterministic fallbacks.
    Never pretends an AI request succeeded if fallback logic was utilized.
    """

    def __init__(self):
        self.gemini_api_key = settings.GEMINI_API_KEY or os.getenv("GEMINI_API_KEY")
        self.openai_api_key = settings.OPENAI_API_KEY or os.getenv("OPENAI_API_KEY")
        self.provider = settings.LLM_PROVIDER.lower() if hasattr(settings, "LLM_PROVIDER") else "gemini"

    def is_ai_available(self) -> bool:
        if self.provider == "gemini" and self.gemini_api_key:
            return True
        if self.provider == "openai" and self.openai_api_key:
            return True
        return False

    async def evaluate_mission_submission(
        self,
        mission_title: str,
        category: str,
        scenario_context: str,
        submission_content: str,
        rubric: List[Dict[str, Any]],
        test_cases: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """
        Evaluate mission submission using objective checks first, then AI or deterministic rubric.
        """
        # Step 1: Run deterministic test cases if present
        test_results = []
        tests_passed = 0
        total_tests = len(test_cases) if test_cases else 0

        if test_cases:
            content_lower = submission_content.lower()
            for tc in test_cases:
                expected = tc.get("expected_pattern", "").lower()
                req_type = tc.get("type", "contains")
                passed = False
                
                if req_type == "contains":
                    passed = expected in content_lower
                elif req_type == "not_contains":
                    passed = expected not in content_lower
                elif req_type == "length_min":
                    passed = len(submission_content.strip()) >= int(expected or 50)
                else:
                    passed = expected in content_lower

                if passed:
                    tests_passed += 1

                test_results.append({
                    "test_name": tc.get("name", "Requirement verification"),
                    "passed": passed,
                    "requirement": tc.get("description", f"Must satisfy: {expected}"),
                    "feedback": "Requirement fulfilled." if passed else tc.get("failure_hint", "Condition not met.")
                })

        # Step 2: Attempt AI evaluation if configured
        if self.is_ai_available() and self.provider == "gemini":
            try:
                ai_result = await self._call_gemini_mission_eval(
                    mission_title, category, scenario_context, submission_content, rubric, test_results
                )
                if ai_result:
                    return {
                        "score": ai_result["score"],
                        "feedback": ai_result["feedback"],
                        "rubric_breakdown": ai_result["rubric_breakdown"],
                        "test_results": test_results,
                        "is_ai_generated": True,
                        "evaluation_engine": "gemini_2_5_flash_evaluator"
                    }
            except Exception as e:
                logger.warning(f"AI evaluation failed, falling back to deterministic rubric: {e}")

        # Step 3: High-fidelity deterministic evaluation engine (transparent & reproducible)
        return self._deterministic_mission_eval(
            mission_title, category, submission_content, rubric, test_results, tests_passed, total_tests
        )

    def _deterministic_mission_eval(
        self,
        mission_title: str,
        category: str,
        submission_content: str,
        rubric: List[Dict[str, Any]],
        test_results: List[Dict[str, Any]],
        tests_passed: int,
        total_tests: int
    ) -> Dict[str, Any]:
        """
        Deterministic rubric scoring based on rubric weights, keyword density, structure, and test execution.
        """
        rubric_breakdown = []
        total_awarded = 0.0
        total_possible = 0.0

        content_words = len(submission_content.split())
        code_lines = len(submission_content.splitlines())

        for idx, item in enumerate(rubric):
            criterion = item.get("criterion", f"Criterion {idx+1}")
            max_pts = float(item.get("max_points", 25))
            total_possible += max_pts

            # Heuristics based on criteria
            crit_lower = criterion.lower()
            awarded = max_pts

            # Check correctness / completeness via tests
            if "correct" in crit_lower or "accuracy" in crit_lower or "syntax" in crit_lower:
                if total_tests > 0:
                    awarded = max_pts * (tests_passed / total_tests)
                else:
                    awarded = max_pts * min(1.0, max(0.5, content_words / 40))
            elif "structure" in crit_lower or "documentation" in crit_lower or "formatting" in crit_lower:
                if code_lines < 3 and content_words < 20:
                    awarded = max_pts * 0.4
                elif any(delim in submission_content for delim in ["--", "/*", "#", "//", "```", "\n\n"]):
                    awarded = max_pts * 1.0
                else:
                    awarded = max_pts * 0.75
            elif "edge" in crit_lower or "robustness" in crit_lower or "error" in crit_lower:
                if any(k in submission_content.lower() for k in ["null", "where", "filter", "try", "except", "error", "coalesce", "validate", "if"]):
                    awarded = max_pts * 1.0
                else:
                    awarded = max_pts * 0.65
            else:
                awarded = max_pts * min(1.0, max(0.6, content_words / 35))

            awarded = round(awarded, 1)
            total_awarded += awarded

            rubric_breakdown.append({
                "criterion": criterion,
                "max_points": max_pts,
                "points_awarded": awarded,
                "notes": f"Scored {awarded}/{max_pts} based on systematic criteria evaluation."
            })

        score_pct = round((total_awarded / total_possible) * 100, 1) if total_possible > 0 else 75.0

        feedback = (
            f"Submission evaluated for '{mission_title}'. "
            f"Demonstrated solid competence across {tests_passed}/{total_tests} test assertions. "
            f"Total rubric score: {score_pct}%. "
            f"{'Excellent application of best practices!' if score_pct >= 85 else 'Good foundation; review rubric notes to refine corner case handling.'}"
        )

        return {
            "score": score_pct,
            "feedback": feedback,
            "rubric_breakdown": rubric_breakdown,
            "test_results": test_results,
            "is_ai_generated": False,
            "evaluation_engine": "deterministic_rule_engine"
        }

    async def _call_gemini_mission_eval(
        self,
        mission_title: str,
        category: str,
        scenario_context: str,
        submission_content: str,
        rubric: List[Dict[str, Any]],
        test_results: List[Dict[str, Any]]
    ) -> Optional[Dict[str, Any]]:
        # Structured Gemini API call with safety and JSON mode
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={self.gemini_api_key}"
        
        prompt = f"""
You are a senior technical assessor for corporate talent.
Evaluate this submission for the mission "{mission_title}" ({category}).
Scenario: {scenario_context}

User Submission:
{submission_content}

Evaluation Rubric:
{json.dumps(rubric)}

Automated Test Results:
{json.dumps(test_results)}

Output pure valid JSON in this exact schema:
{{
  "score": <float between 0 and 100>,
  "feedback": "<concise constructive feedback>",
  "rubric_breakdown": [
     {{"criterion": "<string>", "max_points": <float>, "points_awarded": <float>, "notes": "<string>"}}
  ]
}}
"""
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(
                url,
                json={"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"response_mime_type": "application/json"}}
            )
            if resp.status_code == 200:
                data = resp.json()
                text = data["candidates"][0]["content"]["parts"][0]["text"]
                return json.loads(text)
        return None

    def generate_scenario_debrief(
        self,
        scenario_title: str,
        steps_history: List[Dict[str, Any]],
        final_metrics: Dict[str, int],
        total_score: float
    ) -> Dict[str, Any]:
        """
        Produce a comprehensive debrief explaining decisions made during a consequence-based scenario.
        """
        trust = final_metrics.get("trust", 50)
        risk = final_metrics.get("risk", 50)
        resolution = final_metrics.get("speed", 50)

        debrief_lines = [
            f"Scenario Analysis: '{scenario_title}'.",
            f"Final Decision Health: Stakeholder Trust at {trust}%, Operational Risk at {risk}%, Resolution Efficiency at {resolution}%.",
            f"Overall Decision Alignment Score: {round(total_score, 1)}/100."
        ]

        if total_score >= 85:
            rating = "Exemplary Strategic Alignment"
            debrief_lines.append("Key Strength: Proactive communication and balanced risk containment preserved executive confidence while resolving team tensions.")
        elif total_score >= 70:
            rating = "Proficient with Minor Blindspots"
            debrief_lines.append("Good outcome: Core issues were contained. In future iterations, anticipate secondary ripple effects on team morale earlier.")
        else:
            rating = "High Risk / Needs De-escalation Coaching"
            debrief_lines.append("Critical learning point: Reactive decisions caused unnecessary escalation or elevated operational risk. Focus on root-cause alignment before committing timelines.")

        return {
            "performance_rating": rating,
            "debrief_notes": " ".join(debrief_lines),
            "is_ai_generated": False,
            "evaluation_engine": "deterministic_scenario_analyzer"
        }

    def explain_skill_gap(
        self,
        target_role: str,
        skill_name: str,
        current_level: float,
        target_level: float
    ) -> str:
        """
        Provide clear explanation for why a skill was recommended for improvement.
        """
        gap = target_level - current_level
        if gap <= 0:
            return f"Demonstrated proficiency in {skill_name} meets the benchmark ({target_level:.1f}/5.0) required for {target_role}."
        elif current_level == 0.0:
            return f"No verifiable assessment or project evidence currently exists for {skill_name}. Benchmark requirement for {target_role} is {target_level:.1f}/5.0."
        else:
            return f"{skill_name} is currently demonstrated at level {current_level:.1f}/5.0. Advancing to {target_level:.1f}/5.0 is critical for {target_role} responsibilities."

ai_service = AIService()
