import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Briefcase,
  Clock,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Filter,
  Sparkles,
  Terminal,
  Database,
  Code2,
  MessageSquare
} from "lucide-react";
import { api } from "../lib/api";
import { Mission } from "../lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/common/Card";
import { Button } from "../components/common/Button";
import { Badge } from "../components/common/Badge";

export const MissionLabPage: React.FC = () => {
  const [missions, setMissions] = useState<Mission[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("ALL");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMissions = async () => {
      try {
        const data = await api.getMissions();
        setMissions(data);
      } catch (err) {
        console.error("Error loading missions:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchMissions();
  }, []);

  const categories = [
    { id: "ALL", label: "All Mission Categories" },
    { id: "SQL & Database Skills", label: "SQL & Databases" },
    { id: "Software Engineering", label: "Software Engineering" },
    { id: "Communication", label: "Incident Communication" },
  ];

  const filteredMissions =
    selectedCategory === "ALL"
      ? missions
      : missions.filter((m) => m.category.toLowerCase().includes(selectedCategory.toLowerCase()));

  const getCategoryIcon = (cat: string) => {
    if (cat.includes("SQL") || cat.includes("Database")) return <Database className="h-4 w-4 text-brand-400" />;
    if (cat.includes("Software")) return <Code2 className="h-4 w-4 text-indigo-400" />;
    return <MessageSquare className="h-4 w-4 text-teal-400" />;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              Real-World Mission Lab
            </h1>
            <Badge variant="brand">Module 2</Badge>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Demonstrate practical capabilities on workplace tasks with automated test assertions and transparent rubrics.
          </p>
        </div>

        {/* Categories Tab */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCategory === c.id
                  ? "bg-brand-600 text-white shadow-sm"
                  : "bg-white dark:bg-navy-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="h-64 flex items-center justify-center text-xs text-slate-400">
          Loading mission catalogue...
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMissions.map((m) => (
            <Card key={m.id} className="flex flex-col justify-between hover:border-brand-500/40 transition-all group">
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800">
                      {getCategoryIcon(m.category)}
                    </div>
                    <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                      {m.category}
                    </span>
                  </div>
                  <Badge variant={m.difficulty === "ADVANCED" ? "danger" : "info"}>
                    {m.difficulty}
                  </Badge>
                </div>
                <CardTitle className="text-base group-hover:text-brand-500 transition-colors">
                  {m.title}
                </CardTitle>
                <CardDescription className="line-clamp-2 mt-1">
                  {m.description}
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="flex flex-wrap gap-1.5">
                  {m.required_skills?.map((sk, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700/60"
                    >
                      {sk}
                    </span>
                  ))}
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-3 text-xs text-slate-400">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" /> {m.estimated_time_minutes} mins
                    </span>
                    <span>•</span>
                    <span className="font-mono">{m.submission_type}</span>
                  </div>

                  {m.user_best_score ? (
                    <div className="flex items-center gap-1 text-xs font-bold text-teal-400">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      <span>{m.user_best_score}%</span>
                    </div>
                  ) : null}
                </div>

                <Link to={`/missions/${m.id}`} className="block">
                  <Button variant={m.user_status === "PASSED" ? "secondary" : "primary"} size="sm" className="w-full text-xs gap-1.5">
                    <span>{m.user_status === "PASSED" ? "Review Submission" : "Launch Mission Workspace"}</span>
                    <ArrowRight className="h-3.5 w-3.5" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};
