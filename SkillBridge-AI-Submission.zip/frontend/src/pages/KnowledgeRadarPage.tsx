import React, { useEffect, useState } from "react";
import {
  BookOpen,
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  Users,
  Plus,
  Clock,
  ArrowRight,
  Filter,
  Eye,
  Building,
  UserCheck
} from "lucide-react";
import { api } from "../lib/api";
import { KnowledgeArticle, KnowledgeRadarAnalytics, CrossTrainingAssignment } from "../lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/common/Card";
import { Button } from "../components/common/Button";
import { Badge } from "../components/common/Badge";

export const KnowledgeRadarPage: React.FC = () => {
  const [articles, setArticles] = useState<KnowledgeArticle[]>([]);
  const [analytics, setAnalytics] = useState<KnowledgeRadarAnalytics | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<KnowledgeArticle | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showCrossTrainModal, setShowCrossTrainModal] = useState(false);
  const [loading, setLoading] = useState(true);

  // Form states
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("Engineering SOP");
  const [summary, setSummary] = useState("");
  const [content, setContent] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const loadData = async () => {
    try {
      const [artRes, anaRes] = await Promise.all([
        api.getKnowledgeArticles(),
        api.getKnowledgeRadarAnalytics()
      ]);
      setArticles(artRes);
      setAnalytics(anaRes);
      if (artRes.length > 0 && !selectedArticle) {
        setSelectedArticle(artRes[0]);
      }
    } catch (err) {
      console.error("Error loading knowledge radar:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !content) return;
    setSubmitting(true);
    try {
      await api.createKnowledgeArticle({
        title,
        category,
        summary: summary || title,
        content,
        review_cadence_days: 90
      });
      setShowCreateModal(false);
      setTitle("");
      setSummary("");
      setContent("");
      await loadData();
    } catch (err) {
      console.error("Failed to create article:", err);
    } finally {
      setSubmitting(false);
    }
  };

  const getSpofBadge = (risk: string) => {
    switch (risk) {
      case "CRITICAL":
        return <Badge variant="danger">Critical SPOF</Badge>;
      case "HIGH":
        return <Badge variant="warning">High Risk</Badge>;
      case "MEDIUM":
        return <Badge variant="brand">Medium Risk</Badge>;
      default:
        return <Badge variant="success">Low Risk • Resilient</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              Knowledge Continuity Radar
            </h1>
            <Badge variant="brand">Module 5</Badge>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Prevent institutional memory loss by detecting Single-Points-of-Failure (SPOFs) and tracking cross-training rotations.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setShowCreateModal(true)}
          className="text-xs gap-1.5 shadow-sm"
        >
          <Plus className="h-4 w-4" />
          <span>Document SOP / Procedure</span>
        </Button>
      </div>

      {loading ? (
        <div className="h-64 flex items-center justify-center text-xs text-slate-400">
          Calculating institutional knowledge continuity metrics...
        </div>
      ) : analytics ? (
        <>
          {/* Radar Health Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="p-4 bg-gradient-to-br from-teal-500/10 to-transparent border-teal-500/20">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                Knowledge Coverage Health
              </span>
              <div className="text-3xl font-extrabold text-teal-400 mt-1">
                {analytics.overall_coverage_health_pct}%
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">
                {analytics.total_articles} Verified Runbooks Scanned
              </span>
            </Card>

            <Card className="p-4">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Critical / High SPOFs</span>
              <div className="text-3xl font-extrabold text-rose-500 mt-1">
                {analytics.critical_spof_count + analytics.high_spof_count}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Relying on a single expert</span>
            </Card>

            <Card className="p-4">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Outdated Review Cadence</span>
              <div className="text-3xl font-extrabold text-amber-500 mt-1">
                {analytics.outdated_review_count}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">&gt; 90 days without audit</span>
            </Card>

            <Card className="p-4">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Active Cross-Trainings</span>
              <div className="text-3xl font-extrabold text-brand-500 mt-1">
                {analytics.active_cross_trainings_count}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Backup apprentices in training</span>
            </Card>
          </div>

          {/* SPOF Alerts Section */}
          {analytics.spof_alerts.length > 0 && (
            <Card className="border-rose-500/30 bg-rose-500/5">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="h-5 w-5 text-rose-500" />
                  <div>
                    <CardTitle className="text-sm text-rose-500">Single-Point-of-Failure (SPOF) Priority Alerts</CardTitle>
                    <CardDescription>Critical business procedures lacking redundant backup personnel</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {analytics.spof_alerts.map((al, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-lg bg-white dark:bg-navy-950 border border-slate-200 dark:border-slate-800 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 dark:text-white">{al.title}</span>
                          <Badge variant="danger">{al.risk_level}</Badge>
                        </div>
                        <div className="text-[11px] text-slate-400">
                          Primary Owner: <span className="text-slate-200 font-medium">{al.primary_owner}</span> •
                          Backup: <span className="text-rose-400 font-medium">{al.backup_owner}</span>
                        </div>
                      </div>

                      <div className="shrink-0">
                        <span className="text-xs text-teal-400 font-semibold bg-teal-500/10 px-2.5 py-1 rounded-md border border-teal-500/20">
                          Action: {al.recommended_action}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Knowledge Articles & SOP Viewer */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Article List */}
            <div className="lg:col-span-5 space-y-3">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                Standard Operating Procedures (SOPs)
              </span>
              {articles.map((art) => (
                <div
                  key={art.id}
                  onClick={() => setSelectedArticle(art)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    selectedArticle?.id === art.id
                      ? "border-brand-500 bg-brand-500/10 dark:bg-brand-950/40 text-slate-900 dark:text-white shadow-sm"
                      : "border-slate-200 dark:border-slate-800 bg-white dark:bg-navy-900 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold truncate">{art.title}</span>
                    {getSpofBadge(art.spof_risk_level)}
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2">
                    <span>SME: {art.owner_name}</span>
                    <span>Backup: {art.backup_owner_name || "None (SPOF)"}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Selected Article Viewer */}
            <div className="lg:col-span-7">
              {selectedArticle ? (
                <Card>
                  <CardHeader>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-semibold text-brand-400 uppercase tracking-wider">
                            {selectedArticle.category}
                          </span>
                          {getSpofBadge(selectedArticle.spof_risk_level)}
                        </div>
                        <CardTitle className="text-lg mt-1">{selectedArticle.title}</CardTitle>
                      </div>

                      <div className="text-right text-xs text-slate-400">
                        <span>Review Cadence: Every {selectedArticle.review_cadence_days} days</span>
                        <div className="text-[11px] text-teal-400 mt-0.5">
                          Last Audited: {new Date(selectedArticle.last_reviewed_at).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    {/* Ownership & Backup info */}
                    <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 grid grid-cols-2 text-xs gap-3">
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase">Primary Subject Matter Expert</span>
                        <span className="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 mt-0.5">
                          <UserCheck className="h-3.5 w-3.5 text-teal-400" />
                          {selectedArticle.owner_name}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase">Designated Cross-Training Backup</span>
                        <span className={`font-semibold flex items-center gap-1.5 mt-0.5 ${
                          selectedArticle.backup_owner_name ? "text-emerald-400" : "text-rose-400"
                        }`}>
                          <Users className="h-3.5 w-3.5" />
                          {selectedArticle.backup_owner_name || "None Assigned (High SPOF)"}
                        </span>
                      </div>
                    </div>

                    {/* Markdown Content Display */}
                    <div className="p-4 rounded-xl bg-slate-950 text-slate-200 border border-slate-800 font-mono text-xs overflow-x-auto whitespace-pre-wrap leading-relaxed max-h-80 overflow-y-auto">
                      {selectedArticle.content}
                    </div>
                  </CardContent>
                </Card>
              ) : null}
            </div>
          </div>
        </>
      ) : null}

      {/* Create SOP Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Document Standard Operating Procedure (SOP)
              </h3>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateArticle} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Procedure / Runbook Title
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. AWS Multi-Region Disaster Recovery Protocol"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white"
                >
                  <option value="Platform Runbook">Platform Runbook</option>
                  <option value="Engineering SOP">Engineering SOP</option>
                  <option value="Finance & Security SOP">Finance & Security SOP</option>
                  <option value="Incident Response">Incident Response</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Summary / Scope
                </label>
                <input
                  type="text"
                  value={summary}
                  onChange={(e) => setSummary(e.target.value)}
                  placeholder="Short explanation of when and why this SOP is executed..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Procedure Markdown (Steps, commands, prerequisites)
                </label>
                <textarea
                  required
                  rows={6}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="# Step 1: Drain active queue&#10;# Step 2: Switch DNS Route53 alias..."
                  className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <Button variant="ghost" size="sm" type="button" onClick={() => setShowCreateModal(false)} className="text-xs">
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit" isLoading={submitting} className="text-xs">
                  Save & Publish SOP
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
