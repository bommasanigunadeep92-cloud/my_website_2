import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Building,
  Users,
  Briefcase,
  AlertTriangle,
  BookOpen,
  Award,
  TrendingUp,
  Shield,
  Filter,
  CheckCircle2,
  Clock,
  ArrowRight
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  LineChart,
  Line
} from "recharts";
import { api } from "../lib/api";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/common/Card";
import { Button } from "../components/common/Button";
import { Badge } from "../components/common/Badge";

export const CorporateDashboard: React.FC = () => {
  const [overview, setOverview] = useState<any>(null);
  const [teamSkills, setTeamSkills] = useState<any[]>([]);
  const [learners, setLearners] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<"overview" | "team" | "audit">("overview");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCorporateData = async () => {
      try {
        const [ovRes, skRes, lrRes, logRes] = await Promise.all([
          api.getCorporateOverview(),
          api.getCorporateTeamSkills(),
          api.getCorporateLearners(),
          api.getCorporateAuditLogs()
        ]);
        setOverview(ovRes);
        setTeamSkills(skRes);
        setLearners(lrRes);
        setAuditLogs(logRes);
      } catch (err) {
        console.error("Error loading corporate data:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchCorporateData();
  }, []);

  if (loading || !overview) {
    return (
      <div className="h-64 flex items-center justify-center text-xs text-slate-400">
        Aggregating organizational talent metrics...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              Corporate & Talent Analytics Hub
            </h1>
            <Badge variant="brand">Enterprise Executive</Badge>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Aggregate workforce readiness, failure pattern remediation, and organizational knowledge continuity across {overview.organization_name}.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-900 rounded-lg text-xs">
          <button
            onClick={() => setActiveTab("overview")}
            className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
              activeTab === "overview"
                ? "bg-white dark:bg-navy-950 text-slate-900 dark:text-white shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            Overview & Metrics
          </button>
          <button
            onClick={() => setActiveTab("team")}
            className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
              activeTab === "team"
                ? "bg-white dark:bg-navy-950 text-slate-900 dark:text-white shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            Team Members ({learners.length})
          </button>
          <button
            onClick={() => setActiveTab("audit")}
            className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
              activeTab === "audit"
                ? "bg-white dark:bg-navy-950 text-slate-900 dark:text-white shadow-sm"
                : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            Security Audit Logs
          </button>
        </div>
      </div>

      {activeTab === "overview" && (
        <div className="space-y-6">
          {/* KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="p-4 bg-gradient-to-br from-brand-500/10 to-transparent border-brand-500/20">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Team Members Monitored</span>
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
                {overview.total_learners} Learners
              </div>
              <span className="text-[11px] text-teal-400 mt-1 block">Active Continuous Progression</span>
            </Card>

            <Card className="p-4">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Mission Pass Rate</span>
              <div className="text-3xl font-extrabold text-teal-400 mt-1">
                {overview.mission_pass_rate}%
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">
                {overview.total_missions_completed} Practical Labs Passed
              </span>
            </Card>

            <Card className="p-4">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Avg Diagnostic Score</span>
              <div className="text-3xl font-extrabold text-indigo-400 mt-1">
                {overview.avg_assessment_score}%
              </div>
              <span className="text-[11px] text-emerald-400 mt-1 block">Consistent Baseline Gain</span>
            </Card>

            <Card className="p-4">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Knowledge Coverage Health</span>
              <div className="text-3xl font-extrabold text-emerald-500 mt-1">
                {overview.knowledge_coverage_health_pct}%
              </div>
              <span className="text-[11px] text-rose-400 mt-1 block">
                {overview.critical_knowledge_risks} SPOFs require backup learners
              </span>
            </Card>
          </div>

          {/* Team Skill Gap Distribution Chart */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Organization Skill Benchmark Distribution</CardTitle>
                  <CardDescription>Team average demonstrated level vs benchmark target across core skills</CardDescription>
                </div>
                <Badge variant="brand">1.0 – 5.0 Scale</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="w-full h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={teamSkills}
                    margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.25} />
                    <XAxis dataKey="skill_name" stroke="#94a3b8" fontSize={11} interval={0} angle={-15} textAnchor="end" height={60} />
                    <YAxis domain={[0, 5]} stroke="#94a3b8" fontSize={11} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#0f172a",
                        borderColor: "#334155",
                        borderRadius: "8px",
                        fontSize: "12px",
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: "11px" }} />
                    <Bar dataKey="team_average" name="Team Average" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="benchmark_target" name="Role Benchmark" fill="#14b8a6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Monthly Progression Trend */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <Card className="lg:col-span-8">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Continuous Assessment & Pass Rate Trend</CardTitle>
                    <CardDescription>Monthly evaluations and pass rate progression</CardDescription>
                  </div>
                  <Badge variant="teal">6-Month Trend</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="w-full h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={overview.monthly_trend}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.25} />
                      <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} />
                      <YAxis stroke="#94a3b8" fontSize={11} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#0f172a",
                          borderColor: "#334155",
                          borderRadius: "8px",
                          fontSize: "12px",
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: "11px" }} />
                      <Line type="monotone" dataKey="pass_rate" name="Pass Rate (%)" stroke="#14b8a6" strokeWidth={2.5} />
                      <Line type="monotone" dataKey="assessments" name="Assessments Taken" stroke="#8b5cf6" strokeWidth={2.5} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Knowledge & Failure summary */}
            <Card className="lg:col-span-4 flex flex-col justify-between">
              <CardHeader>
                <CardTitle className="text-sm">Talent Continuity Highlights</CardTitle>
                <CardDescription>Core metrics summary</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 space-y-1">
                  <span className="text-[11px] text-slate-400 uppercase block">Active Failure Clusters</span>
                  <span className="text-xl font-bold text-amber-500 font-mono">
                    {overview.active_failure_patterns_count || 1} Clustered Pattern
                  </span>
                  <p className="text-[10px] text-slate-400">
                    SQL Window Functions has 3 clustered reports. Remediation assigned.
                  </p>
                </div>

                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 space-y-1">
                  <span className="text-[11px] text-slate-400 uppercase block">Critical Knowledge SPOFs</span>
                  <span className="text-xl font-bold text-rose-500 font-mono">
                    {overview.critical_knowledge_risks || 2} Critical Runbooks
                  </span>
                  <p className="text-[10px] text-slate-400">
                    Monthly PCI Audit and Disaster Recovery need shadow rotation.
                  </p>
                </div>

                <Link to="/knowledge" className="block pt-2">
                  <Button variant="outline" size="sm" className="w-full text-xs">
                    Inspect Knowledge Radar
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Team Members Tab */}
      {activeTab === "team" && (
        <Card>
          <CardHeader>
            <CardTitle>Team Learning Participation & Mastery</CardTitle>
            <CardDescription>Individual practitioner development records across the organization</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-200 dark:border-slate-800 text-slate-400 uppercase">
                  <tr>
                    <th className="pb-3">Learner</th>
                    <th className="pb-3">Department</th>
                    <th className="pb-3">Target Role</th>
                    <th className="pb-3 text-center">Missions Passed</th>
                    <th className="pb-3 text-center">Assessments</th>
                    <th className="pb-3 text-center">Avg Score</th>
                    <th className="pb-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                  {learners.map((lr) => (
                    <tr key={lr.id} className="hover:bg-slate-50 dark:hover:bg-slate-900/40">
                      <td className="py-3 font-semibold text-slate-900 dark:text-white">
                        <div>{lr.full_name}</div>
                        <div className="text-[10px] text-slate-400 font-normal">{lr.email}</div>
                      </td>
                      <td className="py-3 text-slate-600 dark:text-slate-300">{lr.department}</td>
                      <td className="py-3 text-brand-500 font-medium">{lr.target_role}</td>
                      <td className="py-3 text-center font-mono font-bold text-teal-400">
                        {lr.missions_completed}
                      </td>
                      <td className="py-3 text-center font-mono">{lr.assessments_taken}</td>
                      <td className="py-3 text-center font-mono font-bold text-slate-800 dark:text-slate-200">
                        {lr.avg_assessment_score}%
                      </td>
                      <td className="py-3 text-right">
                        <Link to="/passport">
                          <Button variant="outline" size="sm" className="text-[11px] h-7">
                            View Passport
                          </Button>
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Security Audit Trail Tab */}
      {activeTab === "audit" && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>System & Compliance Audit Trail</CardTitle>
                <CardDescription>Immutable record of assessment completions, mission submissions, and security events</CardDescription>
              </div>
              <Badge variant="outline">Enterprise Audit Log</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {auditLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-navy-900 text-xs flex items-center justify-between gap-4 font-mono"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-brand-500">{log.action}</span>
                    <span className="text-slate-400 text-[11px]">{log.user_email}</span>
                    <span className="text-[11px] text-slate-500">{log.resource_type} • ID: {log.resource_id}</span>
                  </div>
                  <span className="text-[10px] text-slate-400">
                    {new Date(log.created_at).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
