import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  AlertTriangle,
  ShieldCheck,
  CheckCircle2,
  TrendingUp,
  Plus,
  Lock,
  ArrowRight,
  EyeOff,
  Sparkles,
  BookOpen,
  Briefcase
} from "lucide-react";
import { api } from "../lib/api";
import { Skill, FailurePattern, InterventionTracking } from "../lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/common/Card";
import { Button } from "../components/common/Button";
import { Badge } from "../components/common/Badge";

export const FailurePreventionPage: React.FC = () => {
  const [skills, setSkills] = useState<Skill[]>([]);
  const [patterns, setPatterns] = useState<FailurePattern[]>([]);
  const [interventions, setInterventions] = useState<InterventionTracking[]>([]);
  const [showReportModal, setShowReportModal] = useState(false);
  const [loading, setLoading] = useState(true);

  // Form states
  const [skillId, setSkillId] = useState("");
  const [topic, setTopic] = useState("");
  const [description, setDescription] = useState("");
  const [errorSnippet, setErrorSnippet] = useState("");
  const [emotionalBlocker, setEmotionalBlocker] = useState("Confused on syntax");
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const loadData = async () => {
    try {
      const [skillsRes, patternsRes, intRes] = await Promise.all([
        api.getSkills(),
        api.getFailurePatterns(),
        api.getMyInterventions(),
      ]);
      setSkills(skillsRes);
      setPatterns(patternsRes);
      setInterventions(intRes);
      if (skillsRes.length > 0 && !skillId) {
        setSkillId(skillsRes[0].id);
      }
    } catch (err) {
      console.error("Error loading failure loop data:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!skillId || !topic || !description) return;
    setSubmitting(true);
    try {
      await api.submitFailureReport({
        skill_id: skillId,
        topic,
        description,
        error_snippet: errorSnippet,
        emotional_blocker: emotionalBlocker,
        is_anonymous: isAnonymous,
      });
      setShowReportModal(false);
      // Reset form
      setTopic("");
      setDescription("");
      setErrorSnippet("");
      // Refresh patterns
      await loadData();
    } catch (err) {
      console.error("Failed to submit failure report:", err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleSimulateCompletion = async (intId: string) => {
    try {
      await api.completeIntervention(intId, {
        post_intervention_score: 94.5,
        learner_feedback: "Completed targeted micro-practice exercise. The syntax boundaries are now completely clear.",
      });
      await loadData();
    } catch (err) {
      console.error("Failed to complete intervention:", err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              Skill Failure Prevention Loop
            </h1>
            <Badge variant="warning">Module 3</Badge>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Detect recurring learning difficulties, cluster conceptual roadblocks, and prove measured post-remediation improvement.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setShowReportModal(true)}
          className="text-xs gap-1.5 shadow-sm"
        >
          <Plus className="h-4 w-4" />
          <span>Report Learning Difficulty</span>
        </Button>
      </div>

      {/* Privacy & Governance Safeguard Alert */}
      <div className="p-4 rounded-xl border border-teal-500/30 bg-teal-500/10 text-xs text-slate-800 dark:text-teal-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <ShieldCheck className="h-5 w-5 text-teal-400 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <span className="font-bold text-slate-900 dark:text-white block">
              Organizational Privacy & Fairness Safeguards Active
            </span>
            <p className="text-slate-600 dark:text-teal-300/80 leading-relaxed">
              Reports never impact performance reviews or employment standing. Aggregated cluster views require a minimum threshold of 3+ reporting learners before appearing in management analytics. Optional anonymous reporting is always honored.
            </p>
          </div>
        </div>
        <div className="shrink-0 flex items-center gap-2">
          <span className="text-[10px] font-mono px-2 py-1 rounded bg-teal-500/20 text-teal-300 font-semibold uppercase">
            Threshold: 3+ Learners
          </span>
        </div>
      </div>

      {loading ? (
        <div className="h-64 flex items-center justify-center text-xs text-slate-400">
          Clustering organizational failure patterns...
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Active Patterns Column */}
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                Detected Recurring Difficulty Patterns
              </span>
              <span className="text-xs text-brand-500 font-medium">
                {patterns.length} Active Pattern{patterns.length === 1 ? "" : "s"}
              </span>
            </div>

            {patterns.map((p) => (
              <Card key={p.id} className="border-amber-500/30 bg-gradient-to-br from-amber-500/5 to-transparent">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <Badge variant="warning">{p.skill_name}</Badge>
                        <span className="text-[11px] font-mono text-slate-400">
                          {p.report_count} Reports Clustered
                        </span>
                      </div>
                      <CardTitle className="text-base mt-1.5">{p.cluster_title}</CardTitle>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-bold text-teal-400 block font-mono">
                        {(p.confidence_score * 100).toFixed(0)}%
                      </span>
                      <span className="text-[10px] text-slate-400">Pattern Confidence</span>
                    </div>
                  </div>
                  <CardDescription className="text-slate-600 dark:text-slate-300 mt-2">
                    {p.intervention_details?.description}
                  </CardDescription>
                </CardHeader>

                <CardContent className="space-y-3 pt-0">
                  <div className="p-3 rounded-lg bg-white dark:bg-navy-950 border border-slate-200 dark:border-slate-800 space-y-2">
                    <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <Sparkles className="h-3.5 w-3.5 text-brand-500" />
                      Targeted Remediation Exercise:
                    </span>
                    <p className="text-xs text-slate-700 dark:text-slate-300 font-mono bg-slate-100 dark:bg-slate-900 p-2.5 rounded">
                      {p.intervention_details?.practice_prompt}
                    </p>

                    {p.intervention_details?.refresher_steps && (
                      <div className="space-y-1 pt-1 text-[11px] text-slate-500 dark:text-slate-400">
                        {p.intervention_details.refresher_steps.map((step, sIdx) => (
                          <div key={sIdx}>{step}</div>
                        ))}
                      </div>
                    )}
                  </div>

                  {p.intervention_details?.linked_mission_id && (
                    <div className="flex items-center justify-between text-xs pt-2">
                      <span className="text-slate-400">Linked Verification Lab:</span>
                      <Link to={`/missions/${p.intervention_details.linked_mission_id}`}>
                        <Button variant="outline" size="sm" className="text-xs gap-1">
                          <Briefcase className="h-3.5 w-3.5" />
                          <span>Practice in Mission Lab</span>
                        </Button>
                      </Link>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Remediation Evidence Tracking Column */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                Measurable Remediation Tracking
              </span>
              <span className="text-xs text-teal-400 font-semibold flex items-center gap-1">
                <TrendingUp className="h-3.5 w-3.5" /> Proven Deltas
              </span>
            </div>

            {interventions.length === 0 ? (
              <Card className="p-6 text-center text-xs text-slate-400">
                No interventions currently assigned. Submit a difficulty report to trigger the loop.
              </Card>
            ) : (
              interventions.map((intItem) => (
                <Card key={intItem.id} className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {intItem.failure_pattern_title}
                    </span>
                    <Badge variant={intItem.status === "COMPLETED" ? "success" : "brand"}>
                      {intItem.status}
                    </Badge>
                  </div>

                  {/* Pre vs Post Comparison Box */}
                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 grid grid-cols-3 text-center gap-2">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase block">Pre-Score</span>
                      <span className="text-sm font-bold text-rose-500 font-mono">
                        {intItem.pre_intervention_score}%
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase block">Post-Score</span>
                      <span className="text-sm font-bold text-teal-400 font-mono">
                        {intItem.post_intervention_score ? `${intItem.post_intervention_score}%` : "Pending"}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase block">Delta</span>
                      <span className="text-sm font-extrabold text-emerald-500 font-mono">
                        {intItem.score_delta ? `+${intItem.score_delta}%` : "—"}
                      </span>
                    </div>
                  </div>

                  {intItem.learner_feedback && (
                    <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-[11px] text-emerald-800 dark:text-emerald-300">
                      <span className="font-semibold block mb-0.5">Learner Verification Notes:</span>
                      "{intItem.learner_feedback}"
                    </div>
                  )}

                  {intItem.status !== "COMPLETED" && (
                    <Button
                      variant="teal"
                      size="sm"
                      onClick={() => handleSimulateCompletion(intItem.id)}
                      className="w-full text-xs"
                    >
                      Complete Remedial Exercise (+46.5% Delta)
                    </Button>
                  )}
                </Card>
              ))
            )}
          </div>
        </div>
      )}

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Report Learning Difficulty
                </h3>
              </div>
              <button
                onClick={() => setShowReportModal(false)}
                className="text-slate-400 hover:text-slate-200 text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitReport} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Relevant Skill Category
                </label>
                <select
                  value={skillId}
                  onChange={(e) => setSkillId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white"
                >
                  {skills.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.category})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Specific Topic / Conceptual Blocker
                </label>
                <input
                  type="text"
                  required
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="e.g. SQL Window Functions PARTITION BY"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  What specific mistake or confusion occurred?
                </label>
                <textarea
                  required
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Explain where the query or code broke, or what mental model felt ambiguous..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Error Message or Snippet (Optional)
                </label>
                <input
                  type="text"
                  value={errorSnippet}
                  onChange={(e) => setErrorSnippet(e.target.value)}
                  placeholder="e.g. ERROR: column must appear in GROUP BY"
                  className="w-full px-3 py-2 text-xs rounded-lg font-mono border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white"
                />
              </div>

              <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <EyeOff className="h-4 w-4 text-slate-400" />
                  <div>
                    <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 block">
                      Submit Anonymously
                    </span>
                    <span className="text-[10px] text-slate-400">
                      Your identity will be masked even from team managers.
                    </span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                  className="h-4 w-4 rounded text-brand-600 focus:ring-brand-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <Button variant="ghost" size="sm" type="button" onClick={() => setShowReportModal(false)} className="text-xs">
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit" isLoading={submitting} className="text-xs">
                  Submit Learning Report
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
