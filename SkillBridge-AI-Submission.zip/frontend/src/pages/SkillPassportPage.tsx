import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Award,
  ShieldCheck,
  Share2,
  Copy,
  Check,
  ExternalLink,
  Printer,
  Plus,
  Lock,
  Globe,
  FileCheck2,
  Sparkles,
  Calendar,
  CheckCircle2
} from "lucide-react";
import { api } from "../lib/api";
import { SkillPassport, PassportEvidence, Skill } from "../lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/common/Card";
import { Button } from "../components/common/Button";
import { Badge } from "../components/common/Badge";

export const SkillPassportPage: React.FC = () => {
  const [passport, setPassport] = useState<SkillPassport | null>(null);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showAddEvidenceModal, setShowAddEvidenceModal] = useState(false);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  // Add evidence form state
  const [selectedSkillId, setSelectedSkillId] = useState("");
  const [evidenceType, setEvidenceType] = useState("PROJECT_DEMONSTRATED");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const loadPassport = async () => {
    try {
      const [pRes, sRes] = await Promise.all([api.getMyPassport(), api.getSkills()]);
      setPassport(pRes);
      setSkills(sRes);
      if (sRes.length > 0 && !selectedSkillId) {
        setSelectedSkillId(sRes[0].id);
      }
    } catch (err) {
      console.error("Error loading passport:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPassport();
  }, []);

  const handleCopyLink = () => {
    if (!passport) return;
    const shareUrl = `${window.location.origin}/passport/share/${passport.share_token}`;
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTogglePrivacy = async () => {
    if (!passport) return;
    try {
      const updated = await api.updatePassportSettings({
        is_public: !passport.is_public,
      });
      setPassport(updated);
    } catch (err) {
      console.error("Failed to update privacy:", err);
    }
  };

  const handleGenerateNewToken = async () => {
    try {
      const updated = await api.updatePassportSettings({
        generate_new_token: true,
      });
      setPassport(updated);
    } catch (err) {
      console.error("Failed to rotate share token:", err);
    }
  };

  const handleAddEvidence = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSkillId || !title || !description) return;
    setSubmitting(true);
    try {
      await api.addCustomEvidence({
        skill_id: selectedSkillId,
        evidence_type: evidenceType,
        title,
        description,
        rubric_score: 90.0,
      });
      setShowAddEvidenceModal(false);
      setTitle("");
      setDescription("");
      await loadPassport();
    } catch (err) {
      console.error("Failed to add custom evidence:", err);
    } finally {
      setSubmitting(false);
    }
  };

  const getEvidenceBadge = (type: string) => {
    switch (type) {
      case "PLATFORM_ASSESSED":
        return <Badge variant="brand">Platform Assessed (Diagnostic)</Badge>;
      case "PROJECT_DEMONSTRATED":
        return <Badge variant="success">Project Demonstrated (Mission)</Badge>;
      case "EXTERNALLY_VERIFIED":
        return <Badge variant="teal">Externally / Peer Verified</Badge>;
      default:
        return <Badge variant="outline">Self-Reported Attestation</Badge>;
    }
  };

  if (loading || !passport) {
    return (
      <div className="h-64 flex items-center justify-center text-xs text-slate-400">
        Loading evidence-based skill passport...
      </div>
    );
  }

  const shareUrl = `${window.location.origin}/passport/share/${passport.share_token}`;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              Evidence-Based Skill Passport
            </h1>
            <Badge variant="teal">Module 6</Badge>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Portable, verifiable portfolio distinguishing self-reported claims from platform-assessed diagnostics and tested project artifacts.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.print()}
            className="text-xs gap-1.5"
          >
            <Printer className="h-4 w-4" />
            <span className="hidden sm:inline">Export / Print</span>
          </Button>

          <Button
            variant="secondary"
            size="sm"
            onClick={() => setShowAddEvidenceModal(true)}
            className="text-xs gap-1.5"
          >
            <Plus className="h-4 w-4" />
            <span>Add Evidence Item</span>
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={() => setShowShareModal(true)}
            className="text-xs gap-1.5 shadow-sm"
          >
            <Share2 className="h-4 w-4" />
            <span>Share Verified Passport</span>
          </Button>
        </div>
      </div>

      {/* Main Passport Card */}
      <div className="rounded-2xl border border-brand-500/30 bg-gradient-to-b from-brand-950/20 via-navy-900 to-navy-950 p-6 sm:p-8 space-y-6 shadow-xl">
        {/* Top Passport Profile Banner */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 pb-6 border-b border-slate-800">
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 rounded-2xl bg-gradient-to-tr from-brand-600 to-teal-500 p-0.5 shadow-lg">
              <div className="h-full w-full bg-navy-950 rounded-[14px] flex items-center justify-center text-xl font-bold text-white">
                {passport.user_name.charAt(0)}
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold text-white">{passport.user_name}</h2>
                <Badge variant="success">
                  <ShieldCheck className="h-3 w-3 mr-1" /> Verified Badge
                </Badge>
              </div>
              <p className="text-xs text-brand-300 font-medium mt-0.5">{passport.headline}</p>
              <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                <span>{passport.organization_name}</span>
                <span>•</span>
                <span>Target: {passport.target_role}</span>
              </div>
            </div>
          </div>

          <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-1">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider">Verification Authority</span>
            <span className="text-xs font-mono text-teal-400 font-semibold">{passport.verification_authority}</span>
            <span className="text-[10px] text-slate-500">Continuous Assessment Standards Active</span>
          </div>
        </div>

        {/* Bio & Governance Disclaimer */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
              Practitioner Bio & Career Focus
            </span>
            <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-4 rounded-xl border border-slate-800">
              {passport.summary_bio}
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2 text-xs">
            <span className="font-bold text-slate-200 block flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" /> Evidence Integrity
            </span>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Every credential item in this passport corresponds to a verified platform diagnostic, automated test execution, or supervised workplace cross-training rotation.
            </p>
          </div>
        </div>

        {/* Evidence Items Section */}
        <div className="space-y-4 pt-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Demonstrated Skill & Project Artifacts ({passport.evidence_items.length})
            </span>
            <span className="text-xs text-teal-400 font-mono">
              Role Readiness: {passport.readiness_score}%
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {passport.evidence_items.map((ev) => (
              <div
                key={ev.id}
                className="p-4 rounded-xl border border-slate-800 bg-navy-900/80 hover:border-brand-500/40 transition-colors space-y-2 flex flex-col justify-between"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-white truncate">{ev.title}</span>
                    {ev.rubric_score && (
                      <span className="text-xs font-mono font-bold text-teal-400">
                        {ev.rubric_score}%
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    {getEvidenceBadge(ev.evidence_type)}
                    <span className="text-[10px] text-slate-400">{ev.skill_name}</span>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed pt-1">
                    {ev.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" /> {new Date(ev.verified_at).toLocaleDateString()}
                  </span>
                  <span className="font-mono text-emerald-500 uppercase">{ev.verification_status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Share2 className="h-5 w-5 text-brand-500" /> Share Skill Passport
              </h3>
              <button onClick={() => setShowShareModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Anyone with this revocable public link can inspect your verified skill credentials without signing in. You can revoke access anytime.
            </p>

            <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
              <span className="text-xs font-mono text-slate-700 dark:text-slate-300 truncate">
                {shareUrl}
              </span>
              <Button variant="secondary" size="sm" onClick={handleCopyLink} className="text-xs gap-1 shrink-0">
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copied ? "Copied" : "Copy"}</span>
              </Button>
            </div>

            <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 block">
                  Public Visibility
                </span>
                <span className="text-[10px] text-slate-400">
                  {passport.is_public ? "Publicly accessible via share token" : "Private (link is disabled)"}
                </span>
              </div>
              <button
                onClick={handleTogglePrivacy}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  passport.is_public ? "bg-brand-600" : "bg-slate-600"
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    passport.is_public ? "translate-x-6" : "translate-x-1"
                  }`}
                />
              </button>
            </div>

            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <button
                onClick={handleGenerateNewToken}
                className="text-xs text-rose-500 hover:underline flex items-center gap-1"
              >
                <span>Revoke & Generate New Token</span>
              </button>
              <Link to={`/passport/share/${passport.share_token}`} target="_blank">
                <Button variant="outline" size="sm" className="text-xs gap-1">
                  <span>Open Public View</span>
                  <ExternalLink className="h-3.5 w-3.5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* Add Custom Evidence Modal */}
      {showAddEvidenceModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Add Custom Skill Evidence
              </h3>
              <button onClick={() => setShowAddEvidenceModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleAddEvidence} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Skill Category
                </label>
                <select
                  value={selectedSkillId}
                  onChange={(e) => setSelectedSkillId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white"
                >
                  {skills.map((s) => (
                    <option key={s.id} value={s.id}>{s.name} ({s.category})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Evidence Tier
                </label>
                <select
                  value={evidenceType}
                  onChange={(e) => setEvidenceType(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white"
                >
                  <option value="PROJECT_DEMONSTRATED">Project Demonstrated (Workplace Artifact)</option>
                  <option value="SELF_REPORTED">Self-Reported Attestation</option>
                  <option value="EXTERNALLY_VERIFIED">Externally Verified Credential</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Evidence Title
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Led Distributed Redis Cache Invalidation Migration"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Description of Demonstrated Capabilities
                </label>
                <textarea
                  required
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Detail what was built, benchmark metrics achieved, and verification criteria..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <Button variant="ghost" size="sm" type="button" onClick={() => setShowAddEvidenceModal(false)} className="text-xs">
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit" isLoading={submitting} className="text-xs">
                  Add to Passport
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
