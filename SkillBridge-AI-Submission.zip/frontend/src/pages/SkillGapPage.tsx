import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Target,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  TrendingUp,
  RefreshCw,
  BookOpen,
  Briefcase,
  PlayCircle
} from "lucide-react";
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend
} from "recharts";
import { api } from "../lib/api";
import { SkillGapAnalysis, RoadmapMilestone } from "../lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/common/Card";
import { Button } from "../components/common/Button";
import { Badge } from "../components/common/Badge";

export const SkillGapPage: React.FC = () => {
  const [selectedRole, setSelectedRole] = useState("Senior Full-Stack Engineer");
  const [availableRoles, setAvailableRoles] = useState<string[]>([
    "Senior Full-Stack Engineer",
    "Cloud Data & Analytics Specialist",
    "DevOps & Reliability Engineer"
  ]);
  const [analysis, setAnalysis] = useState<SkillGapAnalysis | null>(null);
  const [roadmap, setRoadmap] = useState<RoadmapMilestone[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async (role: string) => {
    setLoading(true);
    try {
      const [gapRes, roadmapRes, rolesRes] = await Promise.all([
        api.getSkillGapAnalysis(role),
        api.getRoadmap(),
        api.getTargetRoles()
      ]);
      setAnalysis(gapRes);
      setRoadmap(roadmapRes);
      if (rolesRes.roles?.length) {
        setAvailableRoles(rolesRes.roles);
      }
    } catch (err) {
      console.error("Error loading skill gap analysis:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData(selectedRole);
  }, [selectedRole]);

  const handleRoleChange = async (newRole: string) => {
    setSelectedRole(newRole);
    try {
      await api.setTargetRole(newRole);
    } catch (err) {
      console.error("Failed to persist target role update:", err);
    }
  };

  const handleToggleMilestone = async (id: string) => {
    try {
      await api.toggleMilestone(id);
      const updated = await api.getRoadmap();
      setRoadmap(updated);
    } catch (err) {
      console.error("Failed to toggle milestone:", err);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "PROFICIENT":
        return <Badge variant="success">Proficient</Badge>;
      case "DEVELOPING":
        return <Badge variant="brand">Developing</Badge>;
      case "INSUFFICIENT_EVIDENCE":
        return <Badge variant="warning">Insufficient Evidence</Badge>;
      default:
        return <Badge variant="outline">Not Assessed</Badge>;
    }
  };

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              Smart Skill Gap Detector
            </h1>
            <Badge variant="brand">Module 1</Badge>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Deterministic gap analysis comparing verified demonstrated capabilities against career benchmark requirements.
          </p>
        </div>

        {/* Role Selector */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 whitespace-nowrap">
            Target Workplace Role:
          </label>
          <select
            value={selectedRole}
            onChange={(e) => handleRoleChange(e.target.value)}
            className="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-900 text-slate-900 dark:text-white shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
          >
            {availableRoles.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
        </div>
      </div>

      {loading ? (
        <div className="h-64 flex items-center justify-center text-xs text-slate-400">
          Calculating transparent skill gap rubrics...
        </div>
      ) : analysis ? (
        <>
          {/* Key Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="p-4 bg-gradient-to-br from-brand-500/10 to-transparent border-brand-500/20">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Role Readiness Score</span>
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
                {analysis.overall_readiness_pct}%
              </div>
              <span className="text-[11px] text-teal-500 mt-1 block">
                {analysis.proficient_skills_count} of {analysis.total_skills_required} benchmarks satisfied
              </span>
            </Card>

            <Card className="p-4">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Proficient Skills</span>
              <div className="text-3xl font-extrabold text-emerald-500 mt-1">
                {analysis.proficient_skills_count}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Demonstrated level &gt;= 4.0/5.0</span>
            </Card>

            <Card className="p-4">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Developing Skills</span>
              <div className="text-3xl font-extrabold text-amber-500 mt-1">
                {analysis.developing_skills_count}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Demonstrated level 2.5 – 3.9</span>
            </Card>

            <Card className="p-4">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Missing Evidence / Insufficient</span>
              <div className="text-3xl font-extrabold text-rose-500 mt-1">
                {analysis.missing_evidence_count}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Requires diagnostic lab or mission</span>
            </Card>
          </div>

          {/* Charts Row: Radar Chart + Comparison Bar Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Radar Visualizer */}
            <Card className="lg:col-span-5 flex flex-col">
              <CardHeader>
                <CardTitle>Skill Radar Geometry</CardTitle>
                <CardDescription>Multi-axis benchmark overlay</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col items-center justify-center p-2">
                <div className="w-full h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart cx="50%" cy="50%" outerRadius="75%" data={analysis.radar_data}>
                      <PolarGrid stroke="#334155" opacity={0.3} />
                      <PolarAngleAxis dataKey="skill" tick={{ fill: "#94a3b8", fontSize: 11 }} />
                      <PolarRadiusAxis angle={30} domain={[0, 5]} tick={{ fill: "#64748b", fontSize: 10 }} />
                      <Radar
                        name="Demonstrated"
                        dataKey="demonstrated"
                        stroke="#8b5cf6"
                        fill="#8b5cf6"
                        fillOpacity={0.4}
                      />
                      <Radar
                        name="Target Benchmark"
                        dataKey="required"
                        stroke="#14b8a6"
                        fill="#14b8a6"
                        fillOpacity={0.15}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#0f172a",
                          borderColor: "#334155",
                          borderRadius: "8px",
                          fontSize: "12px",
                        }}
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex items-center gap-6 text-xs text-slate-400 mt-2">
                  <span className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full bg-brand-500" />
                    Current Demonstrated
                  </span>
                  <span className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full bg-teal-500" />
                    Role Benchmark
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Gap Comparison Bars */}
            <Card className="lg:col-span-7 flex flex-col">
              <CardHeader>
                <CardTitle>Benchmarked Skill Gap Delta</CardTitle>
                <CardDescription>Direct point comparisons on 1.0 – 5.0 scale</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col justify-center">
                <div className="w-full h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={analysis.comparison_bars}
                      layout="vertical"
                      margin={{ top: 10, right: 30, left: 40, bottom: 10 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.25} horizontal={false} />
                      <XAxis type="number" domain={[0, 5]} stroke="#94a3b8" fontSize={11} />
                      <YAxis type="category" dataKey="skill" stroke="#94a3b8" fontSize={10} width={130} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#0f172a",
                          borderColor: "#334155",
                          borderRadius: "8px",
                          fontSize: "12px",
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: "11px" }} />
                      <Bar dataKey="current" name="Demonstrated Level" fill="#8b5cf6" radius={[0, 4, 4, 0]} />
                      <Bar dataKey="target" name="Benchmark Level" fill="#14b8a6" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Transparent Explanations & Improvement Areas Table */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Transparent Rubric Explanations</CardTitle>
                  <CardDescription>Why each skill was recommended for improvement</CardDescription>
                </div>
                <Link to="/assessments">
                  <Button variant="teal" size="sm" className="text-xs">
                    Take Diagnostic Lab
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold uppercase tracking-wider">
                    <tr>
                      <th className="pb-3">Skill & Category</th>
                      <th className="pb-3 text-center">Demonstrated</th>
                      <th className="pb-3 text-center">Required</th>
                      <th className="pb-3 text-center">Gap Delta</th>
                      <th className="pb-3">Evidence Tier</th>
                      <th className="pb-3">Transparent Rationale</th>
                      <th className="pb-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                    {[...analysis.strengths, ...analysis.improvement_areas].map((item) => (
                      <tr key={item.skill_id} className="hover:bg-slate-50 dark:hover:bg-slate-900/40 transition-colors">
                        <td className="py-3 font-medium text-slate-900 dark:text-white">
                          <div>{item.skill_name}</div>
                          <div className="text-[10px] text-slate-400">{item.category}</div>
                        </td>
                        <td className="py-3 text-center font-mono font-bold text-slate-800 dark:text-slate-200">
                          {item.demonstrated_level.toFixed(1)}
                        </td>
                        <td className="py-3 text-center font-mono text-slate-500">
                          {item.required_level.toFixed(1)}
                        </td>
                        <td className="py-3 text-center">
                          {item.gap > 0 ? (
                            <span className="text-rose-500 font-bold font-mono">-{item.gap.toFixed(1)}</span>
                          ) : (
                            <span className="text-emerald-500 font-bold font-mono">0.0</span>
                          )}
                        </td>
                        <td className="py-3">
                          {getStatusBadge(item.status)}
                        </td>
                        <td className="py-3 text-slate-600 dark:text-slate-300 max-w-xs leading-relaxed">
                          {item.reason}
                        </td>
                        <td className="py-3 text-right">
                          <Link to="/missions">
                            <Button variant="outline" size="sm" className="text-[11px] h-7 px-2.5">
                              {item.gap > 0 ? "Practice" : "Maintain"}
                            </Button>
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Personalized Learning Roadmap */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Personalized Learning Roadmap</CardTitle>
                  <CardDescription>Sequenced progression milestones tailored to close demonstrated gaps</CardDescription>
                </div>
                <Badge variant="brand">Step-by-Step</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200 dark:before:bg-slate-800">
                {roadmap.map((m) => (
                  <div key={m.id} className="relative flex items-start gap-4">
                    {/* Checkbox circle indicator */}
                    <button
                      onClick={() => handleToggleMilestone(m.id)}
                      className={`absolute -left-6 top-1 h-5 w-5 rounded-full border flex items-center justify-center transition-colors ${
                        m.status === "COMPLETED"
                          ? "bg-emerald-500 border-emerald-500 text-white"
                          : "bg-white dark:bg-navy-900 border-slate-300 dark:border-slate-700 hover:border-brand-500"
                      }`}
                      title="Click to toggle milestone completion"
                    >
                      {m.status === "COMPLETED" && <CheckCircle2 className="h-3.5 w-3.5" />}
                    </button>

                    <div className="flex-1 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-navy-900/60 shadow-sm space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900 dark:text-white">
                            Milestone {m.milestone_order}: {m.title}
                          </span>
                          <Badge variant={m.status === "COMPLETED" ? "success" : "brand"}>
                            {m.status}
                          </Badge>
                        </div>
                        <span className="text-[11px] font-mono text-slate-400">
                          Target: {m.target_level.toFixed(1)}/5.0
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {m.description}
                      </p>
                      <div className="pt-2 flex items-center gap-2">
                        {m.action_type === "MISSION" ? (
                          <Link to="/missions">
                            <Button variant="secondary" size="sm" className="text-xs h-7 gap-1">
                              <Briefcase className="h-3 w-3" />
                              <span>Go to Practical Mission</span>
                            </Button>
                          </Link>
                        ) : (
                          <Link to="/assessments">
                            <Button variant="secondary" size="sm" className="text-xs h-7 gap-1">
                              <Target className="h-3 w-3" />
                              <span>Take Diagnostic Assessment</span>
                            </Button>
                          </Link>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      ) : null}
    </div>
  );
};
