import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import {
  ShieldCheck,
  Award,
  CheckCircle2,
  Calendar,
  Compass,
  Building,
  Printer
} from "lucide-react";
import { api } from "../lib/api";
import { SkillPassport } from "../lib/types";
import { Button } from "../components/common/Button";
import { Badge } from "../components/common/Badge";

export const SharedPassportPage: React.FC = () => {
  const { token } = useParams<{ token: string }>();
  const [passport, setPassport] = useState<SkillPassport | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPublicPassport = async () => {
      if (!token) return;
      try {
        const res = await api.getPublicPassport(token);
        setPassport(res);
      } catch (err: any) {
        setError(err.message || "This Skill Passport is private or the share token was revoked.");
      } finally {
        setLoading(false);
      }
    };

    fetchPublicPassport();
  }, [token]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-6 text-xs text-slate-400">
        Verifying cryptographic passport credentials...
      </div>
    );
  }

  if (error || !passport) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-6 text-center space-y-4">
        <div className="h-12 w-12 rounded-full bg-rose-500/10 text-rose-500 flex items-center justify-center">
          <ShieldCheck className="h-6 w-6" />
        </div>
        <h2 className="text-xl font-bold">Passport Unavailable</h2>
        <p className="text-xs text-slate-400 max-w-md">{error}</p>
        <Link to="/">
          <Button variant="outline" size="sm" className="text-xs">
            Return to SkillBridge AI
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Verification Banner */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <Link to="/" className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-brand-600 flex items-center justify-center">
              <Compass className="h-4 w-4 text-white" />
            </div>
            <span className="text-base font-bold text-white">SkillBridge AI</span>
          </Link>

          <Button
            variant="outline"
            size="sm"
            onClick={() => window.print()}
            className="text-xs gap-1.5"
          >
            <Printer className="h-3.5 w-3.5" />
            <span>Print Verified Portfolio</span>
          </Button>
        </div>

        {/* Passport Card */}
        <div className="rounded-3xl border border-teal-500/30 bg-gradient-to-b from-navy-900 to-navy-950 p-6 sm:p-10 space-y-8 shadow-2xl">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 pb-6 border-b border-slate-800">
            <div className="flex items-center gap-4">
              <div className="h-16 w-16 rounded-2xl bg-gradient-to-tr from-brand-600 to-teal-500 p-0.5 shadow-lg">
                <div className="h-full w-full bg-navy-950 rounded-[14px] flex items-center justify-center text-2xl font-bold text-white">
                  {passport.user_name.charAt(0)}
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl font-extrabold text-white">{passport.user_name}</h1>
                  <Badge variant="success">
                    <ShieldCheck className="h-3 w-3 mr-1" /> Verified Badge
                  </Badge>
                </div>
                <p className="text-xs text-brand-300 font-medium mt-0.5">{passport.headline}</p>
                <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-2">
                  <Building className="h-3 w-3 text-brand-400" />
                  <span>{passport.organization_name}</span>
                </div>
              </div>
            </div>

            <div className="text-left sm:text-right space-y-1">
              <span className="text-[10px] uppercase tracking-wider text-slate-400 block">
                Verification Authority
              </span>
              <span className="text-xs font-mono text-teal-400 font-semibold block">
                {passport.verification_authority}
              </span>
              <span className="text-[11px] text-emerald-400 flex items-center sm:justify-end gap-1">
                <CheckCircle2 className="h-3 w-3" /> Cryptographically Valid
              </span>
            </div>
          </div>

          {/* Bio */}
          {passport.summary_bio && (
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300 leading-relaxed">
              {passport.summary_bio}
            </div>
          )}

          {/* Evidence Items */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Verified Project & Practical Artifacts ({passport.evidence_items.length})
              </span>
              <span className="text-xs font-mono text-teal-400">
                Demonstrated Readiness: {passport.readiness_score}%
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {passport.evidence_items.map((ev) => (
                <div
                  key={ev.id}
                  className="p-4 rounded-xl border border-slate-800 bg-slate-900/40 space-y-2 flex flex-col justify-between"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-white truncate">{ev.title}</span>
                      {ev.rubric_score && (
                        <span className="text-xs font-mono font-bold text-teal-400">
                          {ev.rubric_score}%
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="teal">{ev.evidence_type}</Badge>
                      <span className="text-[10px] text-slate-400">{ev.skill_name}</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed pt-1">
                      {ev.description}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" /> {new Date(ev.verified_at).toLocaleDateString()}
                    </span>
                    <span className="font-mono text-emerald-400 uppercase">{ev.verification_status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Official Verification Notice */}
          <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 text-xs text-slate-400 leading-relaxed text-center space-y-1">
            <span className="font-bold text-slate-300 block">Official Verification Statement:</span>
            <p className="text-[11px]">
              Issued via SkillBridge AI Continuous Evidence Engine. Reflects demonstrated diagnostic scores, test-asserted project artifacts, and supervised workplace rotations. Does not substitute for statutory licensing.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
