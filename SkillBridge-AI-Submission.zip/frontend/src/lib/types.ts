export type UserRole = "LEARNER" | "MANAGER" | "ADMIN";

export type SkillDemonstrationLevel = "NOT_ASSESSED" | "INSUFFICIENT_EVIDENCE" | "DEVELOPING" | "PROFICIENT";

export type MissionDifficulty = "BEGINNER" | "INTERMEDIATE" | "ADVANCED";

export type SubmissionStatus = "SUBMITTED" | "EVALUATED" | "PASSED" | "NEEDS_REVISION";

export type EvidenceType = "SELF_REPORTED" | "PLATFORM_ASSESSED" | "PROJECT_DEMONSTRATED" | "EXTERNALLY_VERIFIED";

export type SpofRiskLevel = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export type InterventionStatus = "ASSIGNED" | "IN_PROGRESS" | "COMPLETED";

export type CrossTrainingStatus = "ASSIGNED" | "IN_PROGRESS" | "VERIFIED";

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  organization_id?: string;
  organization_name?: string;
  department?: string;
  job_title?: string;
  target_role?: string;
  avatar_url?: string;
  is_active: boolean;
  created_at: string;
}

export interface Skill {
  id: string;
  name: string;
  category: string;
  description: string;
  created_at: string;
}

export interface SkillGapItem {
  skill_id: string;
  skill_name: string;
  category: string;
  demonstrated_level: number;
  required_level: number;
  gap: number;
  status: SkillDemonstrationLevel;
  evidence_count: number;
  importance_weight: number;
  reason: string;
  recommended_action: string;
}

export interface SkillGapAnalysis {
  target_role: string;
  overall_readiness_pct: number;
  total_skills_required: number;
  proficient_skills_count: number;
  developing_skills_count: number;
  missing_evidence_count: number;
  strengths: SkillGapItem[];
  improvement_areas: SkillGapItem[];
  radar_data: { skill: string; demonstrated: number; required: number; full_mark: number }[];
  comparison_bars: { skill: string; current: number; target: number; gap: number }[];
  recommendations: { skill_name: string; target_role: string; gap: number; priority: string; action: string }[];
}

export interface RoadmapMilestone {
  id: string;
  target_role: string;
  milestone_order: number;
  title: string;
  description: string;
  target_skill_id?: string;
  target_skill_name?: string;
  target_level: number;
  status: string;
  action_type: string;
  action_id?: string;
  completed_at?: string;
}

export interface LearningResource {
  id: string;
  skill_id: string;
  title: string;
  category?: string;
  resource_type: string;
  url?: string;
  summary: string;
  estimated_minutes: number;
}

export interface AssessmentQuestion {
  id: string;
  skill_id: string;
  skill_name?: string;
  question_text: string;
  question_type: string;
  options?: string[];
  points: number;
  difficulty_level: number;
}

export interface Assessment {
  id: string;
  title: string;
  description: string;
  category: string;
  target_role?: string;
  difficulty: string;
  time_limit_minutes: number;
  passing_score: number;
  question_count: number;
  questions?: AssessmentQuestion[];
}

export interface AssessmentAttempt {
  id: string;
  assessment_id: string;
  assessment_title?: string;
  user_id: string;
  score: number;
  passed: boolean;
  started_at: string;
  completed_at?: string;
  evaluation_detail?: any;
  feedback_notes?: string;
  is_ai_generated: boolean;
  skill_updates?: any[];
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: MissionDifficulty;
  estimated_time_minutes: number;
  scenario_context?: string;
  instructions?: string;
  sample_data?: any;
  submission_type: string;
  required_skills: string[];
  evaluation_rubric?: { criterion: string; max_points: number; description: string }[];
  user_status?: SubmissionStatus;
  user_best_score?: number;
}

export interface MissionSubmission {
  id: string;
  mission_id: string;
  user_id: string;
  submission_content: string;
  status: SubmissionStatus;
  score: number;
  feedback?: string;
  rubric_breakdown?: { criterion: string; points_awarded: number; max_points: number; notes: string }[];
  test_results?: { test_name: string; passed: boolean; requirement: string; feedback: string }[];
  is_ai_generated: boolean;
  evaluation_engine: string;
  submitted_at: string;
  evaluated_at?: string;
}

export interface FailureReport {
  id: string;
  user_id?: string;
  user_name?: string;
  skill_id: string;
  skill_name?: string;
  topic: string;
  description: string;
  error_snippet?: string;
  emotional_blocker?: string;
  is_anonymous: boolean;
  created_at: string;
}

export interface FailurePattern {
  id: string;
  skill_id: string;
  skill_name?: string;
  topic: string;
  cluster_title: string;
  report_count: number;
  confidence_score: number;
  status: string;
  recommended_intervention_type: string;
  intervention_details: {
    title: string;
    description: string;
    practice_prompt: string;
    linked_mission_id?: string;
    refresher_steps?: string[];
  };
  detected_at: string;
  active_interventions_count?: number;
}

export interface InterventionTracking {
  id: string;
  failure_pattern_id: string;
  failure_pattern_title?: string;
  user_id: string;
  status: InterventionStatus;
  pre_intervention_score?: number;
  post_intervention_score?: number;
  score_delta?: number;
  evidence_demonstrated: boolean;
  learner_feedback?: string;
  intervention_details?: any;
  completed_at?: string;
}

export interface ScenarioChoice {
  id: string;
  choice_text: string;
  consequences_narrative: string;
  metrics_delta: Record<string, number>;
  next_step_key?: string | null;
  score_points: number;
  rationale: string;
}

export interface ScenarioStep {
  step_key: string;
  prompt: string;
  situation_update?: string;
  choices: ScenarioChoice[];
}

export interface Scenario {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  estimated_minutes: number;
  learning_objectives: string[];
  context_background?: string;
  initial_step_key?: string;
  rubric?: any[];
  steps?: ScenarioStep[];
  user_attempts_count?: number;
  user_best_score?: number;
}

export interface ScenarioAttempt {
  id: string;
  scenario_id: string;
  scenario_title?: string;
  total_score: number;
  performance_rating: string;
  debrief_notes?: string;
  metrics_summary?: Record<string, any>;
  steps_history: any[];
  is_ai_generated: boolean;
  completed_at: string;
}

export interface KnowledgeArticle {
  id: string;
  organization_id: string;
  title: string;
  category: string;
  summary: string;
  content: string;
  owner_id?: string;
  owner_name?: string;
  backup_owner_id?: string;
  backup_owner_name?: string;
  primary_skill_id?: string;
  primary_skill_name?: string;
  related_skills?: string[];
  review_cadence_days: number;
  last_reviewed_at: string;
  next_review_at?: string;
  spof_risk_level: SpofRiskLevel;
  is_verified_procedure: boolean;
  status: string;
  views_count: number;
  created_at: string;
}

export interface CrossTrainingAssignment {
  id: string;
  organization_id: string;
  knowledge_article_id: string;
  knowledge_article_title?: string;
  primary_expert_id: string;
  primary_expert_name?: string;
  backup_learner_id: string;
  backup_learner_name?: string;
  target_completion_date?: string;
  status: CrossTrainingStatus;
  verification_notes?: string;
  verified_at?: string;
  created_at: string;
}

export interface KnowledgeRadarAnalytics {
  total_articles: number;
  overall_coverage_health_pct: number;
  critical_spof_count: number;
  high_spof_count: number;
  medium_spof_count: number;
  low_spof_count: number;
  outdated_review_count: number;
  active_cross_trainings_count: number;
  spof_alerts: {
    article_id: string;
    title: string;
    category: string;
    risk_level: string;
    primary_owner: string;
    backup_owner: string;
    recommended_action: string;
  }[];
  category_distribution: { category: string; count: number }[];
  recommendations: { priority: string; title: string; description: string }[];
}

export interface PassportEvidence {
  id: string;
  passport_id: string;
  skill_id: string;
  skill_name?: string;
  skill_category?: string;
  evidence_type: EvidenceType;
  title: string;
  description: string;
  rubric_score?: number;
  artifact_ref?: string;
  verification_status: string;
  verified_at: string;
  tags?: string[];
  created_at: string;
}

export interface SkillPassport {
  id: string;
  user_id: string;
  user_name: string;
  user_email: string;
  organization_name?: string;
  department?: string;
  job_title?: string;
  target_role?: string;
  share_token: string;
  is_public: boolean;
  headline: string;
  summary_bio?: string;
  verified_badge: boolean;
  verification_authority: string;
  created_at: string;
  updated_at: string;
  evidence_items: PassportEvidence[];
  assessed_skills_count: number;
  projects_verified_count: number;
  readiness_score: number;
}
