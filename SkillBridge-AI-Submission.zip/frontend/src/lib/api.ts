import {
  User,
  Skill,
  SkillGapAnalysis,
  RoadmapMilestone,
  Assessment,
  AssessmentAttempt,
  Mission,
  MissionSubmission,
  FailureReport,
  FailurePattern,
  InterventionTracking,
  Scenario,
  ScenarioAttempt,
  KnowledgeArticle,
  KnowledgeRadarAnalytics,
  CrossTrainingAssignment,
  SkillPassport,
  PassportEvidence
} from "./types";

const API_BASE = "http://localhost:8000/api/v1";

class ApiClient {
  private getToken(): string | null {
    return localStorage.getItem("skillbridge_token");
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = this.getToken();
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      ...(options.headers as Record<string, string>),
    };

    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    const response = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers,
    });

    if (!response.ok) {
      let errorMessage = "An unexpected server error occurred";
      try {
        const errorData = await response.json();
        errorMessage = errorData.detail || errorData.message || errorMessage;
      } catch {
        // Fallback to text or status text
        errorMessage = response.statusText || errorMessage;
      }
      throw new Error(errorMessage);
    }

    return response.json();
  }

  // Auth
  async login(email: string, password: string): Promise<{ access_token: string; user: User }> {
    return this.request("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
  }

  async register(data: {
    email: string;
    password: string;
    full_name: string;
    role?: string;
    department?: string;
    job_title?: string;
    target_role?: string;
  }): Promise<{ access_token: string; user: User }> {
    return this.request("/auth/register", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async getMe(): Promise<User> {
    return this.request("/auth/me");
  }

  async updateMe(data: Partial<User>): Promise<User> {
    return this.request("/auth/me", {
      method: "PUT",
      body: JSON.stringify(data),
    });
  }

  // Module 1: Skills & Gap Detection
  async getSkills(category?: string): Promise<Skill[]> {
    return this.request(`/skills${category ? `?category=${encodeURIComponent(category)}` : ""}`);
  }

  async getTargetRoles(): Promise<{ roles: string[] }> {
    return this.request("/skills/roles");
  }

  async getSkillGapAnalysis(role?: string): Promise<SkillGapAnalysis> {
    return this.request(`/skills/gap-analysis${role ? `?role=${encodeURIComponent(role)}` : ""}`);
  }

  async setTargetRole(target_role: string): Promise<{ target_role: string }> {
    return this.request("/skills/target-role", {
      method: "POST",
      body: JSON.stringify({ target_role }),
    });
  }

  async getRoadmap(): Promise<RoadmapMilestone[]> {
    return this.request("/skills/roadmap");
  }

  async toggleMilestone(milestoneId: string): Promise<any> {
    return this.request(`/skills/roadmap/milestones/${milestoneId}/toggle`, {
      method: "POST",
    });
  }

  // Diagnostic Assessments
  async getAssessments(category?: string): Promise<Assessment[]> {
    return this.request(`/assessments${category ? `?category=${encodeURIComponent(category)}` : ""}`);
  }

  async getAssessment(id: string): Promise<Assessment> {
    return this.request(`/assessments/${id}`);
  }

  async submitAssessment(id: string, answers: Record<string, string>): Promise<AssessmentAttempt> {
    return this.request(`/assessments/${id}/submit`, {
      method: "POST",
      body: JSON.stringify({ answers }),
    });
  }

  async getAssessmentHistory(): Promise<AssessmentAttempt[]> {
    return this.request("/assessments/history/me");
  }

  // Module 2: Real-World Mission Lab
  async getMissions(category?: string): Promise<Mission[]> {
    return this.request(`/missions${category ? `?category=${encodeURIComponent(category)}` : ""}`);
  }

  async getMission(id: string): Promise<Mission> {
    return this.request(`/missions/${id}`);
  }

  async submitMission(id: string, submission_content: string): Promise<MissionSubmission> {
    return this.request(`/missions/${id}/submit`, {
      method: "POST",
      body: JSON.stringify({ submission_content }),
    });
  }

  async getMySubmissions(): Promise<MissionSubmission[]> {
    return this.request("/missions/submissions/me");
  }

  // Module 3: Skill Failure Prevention Loop
  async submitFailureReport(data: {
    skill_id: string;
    topic: string;
    description: string;
    error_snippet?: string;
    emotional_blocker?: string;
    is_anonymous?: boolean;
  }): Promise<FailureReport> {
    return this.request("/failure-prevention/reports", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async getMyFailureReports(): Promise<FailureReport[]> {
    return this.request("/failure-prevention/reports/me");
  }

  async getFailurePatterns(): Promise<FailurePattern[]> {
    return this.request("/failure-prevention/patterns");
  }

  async getMyInterventions(): Promise<InterventionTracking[]> {
    return this.request("/failure-prevention/interventions/me");
  }

  async completeIntervention(
    trackingId: string,
    data: { post_intervention_score: number; learner_feedback?: string }
  ): Promise<InterventionTracking> {
    return this.request(`/failure-prevention/interventions/${trackingId}/complete`, {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  // Module 4: Consequence-Based Learning Simulator
  async getScenarios(category?: string): Promise<Scenario[]> {
    return this.request(`/scenarios${category ? `?category=${encodeURIComponent(category)}` : ""}`);
  }

  async getScenario(id: string): Promise<Scenario> {
    return this.request(`/scenarios/${id}`);
  }

  async submitScenarioAttempt(
    id: string,
    data: { steps_history: any[]; final_metrics: Record<string, number>; total_score: number }
  ): Promise<ScenarioAttempt> {
    return this.request(`/scenarios/${id}/attempt`, {
      method: "POST",
      body: JSON.stringify({ scenario_id: id, ...data }),
    });
  }

  async getScenarioHistory(): Promise<ScenarioAttempt[]> {
    return this.request("/scenarios/history/me");
  }

  // Module 5: Organizational Knowledge Continuity Radar
  async getKnowledgeArticles(category?: string, spof_risk?: string): Promise<KnowledgeArticle[]> {
    const params = new URLSearchParams();
    if (category) params.append("category", category);
    if (spof_risk) params.append("spof_risk", spof_risk);
    return this.request(`/knowledge/articles?${params.toString()}`);
  }

  async getKnowledgeArticle(id: string): Promise<KnowledgeArticle> {
    return this.request(`/knowledge/articles/${id}`);
  }

  async createKnowledgeArticle(data: {
    title: string;
    category: string;
    summary: string;
    content: string;
    backup_owner_id?: string;
    primary_skill_id?: string;
    review_cadence_days?: number;
  }): Promise<KnowledgeArticle> {
    return this.request("/knowledge/articles", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async getKnowledgeRadarAnalytics(): Promise<KnowledgeRadarAnalytics> {
    return this.request("/knowledge/radar/analytics");
  }

  async createCrossTraining(data: {
    knowledge_article_id: string;
    backup_learner_id: string;
  }): Promise<CrossTrainingAssignment> {
    return this.request("/knowledge/cross-training", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async verifyCrossTraining(id: string, notes?: string): Promise<CrossTrainingAssignment> {
    return this.request(`/knowledge/cross-training/${id}/verify`, {
      method: "PUT",
      body: JSON.stringify({ notes }),
    });
  }

  // Module 6: Evidence-Based Skill Passport
  async getMyPassport(): Promise<SkillPassport> {
    return this.request("/passport/me");
  }

  async updatePassportSettings(data: {
    is_public?: boolean;
    headline?: string;
    summary_bio?: string;
    generate_new_token?: boolean;
  }): Promise<SkillPassport> {
    return this.request("/passport/settings", {
      method: "PUT",
      body: JSON.stringify(data),
    });
  }

  async addCustomEvidence(data: {
    skill_id: string;
    evidence_type: string;
    title: string;
    description: string;
    rubric_score?: number;
    artifact_ref?: string;
    tags?: string[];
  }): Promise<PassportEvidence> {
    return this.request("/passport/evidence", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async getPublicPassport(shareToken: string): Promise<SkillPassport> {
    return this.request(`/passport/public/${encodeURIComponent(shareToken)}`);
  }

  // Corporate & Manager Analytics
  async getCorporateOverview(): Promise<any> {
    return this.request("/corporate/overview");
  }

  async getCorporateTeamSkills(): Promise<any[]> {
    return this.request("/corporate/team-skills");
  }

  async getCorporateLearners(): Promise<any[]> {
    return this.request("/corporate/learners");
  }

  async getCorporateAuditLogs(): Promise<any[]> {
    return this.request("/corporate/audit-logs");
  }
}

export const api = new ApiClient();
