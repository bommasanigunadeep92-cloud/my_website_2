import React, { createContext, useContext, useEffect, useState } from "react";
import { User, UserRole } from "../lib/types";
import { api } from "../lib/api";

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (data: any) => Promise<void>;
  logout: () => void;
  switchDemoUser: (role: UserRole) => Promise<void>;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const fetchCurrentUser = async () => {
    try {
      const token = localStorage.getItem("skillbridge_token");
      if (token) {
        const u = await api.getMe();
        setUser(u);
      }
    } catch (err) {
      console.warn("Failed to fetch current user session:", err);
      localStorage.removeItem("skillbridge_token");
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCurrentUser();
  }, []);

  const login = async (email: string, pass: string) => {
    const res = await api.login(email, pass);
    localStorage.setItem("skillbridge_token", res.access_token);
    setUser(res.user);
  };

  const register = async (data: any) => {
    const res = await api.register(data);
    localStorage.setItem("skillbridge_token", res.access_token);
    setUser(res.user);
  };

  const logout = () => {
    localStorage.removeItem("skillbridge_token");
    setUser(null);
  };

  const switchDemoUser = async (role: UserRole) => {
    setLoading(true);
    try {
      let email = "alex@acme.com";
      let pass = "LearnerPass123!";
      if (role === "MANAGER") {
        email = "manager@acme.com";
        pass = "ManagerPass123!";
      } else if (role === "ADMIN") {
        email = "admin@acme.com";
        pass = "AdminPass123!";
      }
      await login(email, pass);
    } catch (err) {
      console.error("Demo user switch failed:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        register,
        logout,
        switchDemoUser,
        setUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
