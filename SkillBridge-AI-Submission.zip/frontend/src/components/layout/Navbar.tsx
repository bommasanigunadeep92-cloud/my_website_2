import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Compass,
  Bell,
  Sun,
  Moon,
  User as UserIcon,
  LogOut,
  ChevronDown,
  ShieldCheck,
  Building,
  CheckCircle,
  ExternalLink,
  Users
} from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { useTheme } from "../../context/ThemeContext";
import { Badge } from "../common/Badge";
import { UserRole } from "../../lib/types";

export const Navbar: React.FC = () => {
  const { user, logout, switchDemoUser } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();

  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showPersonaMenu, setShowPersonaMenu] = useState(false);

  const notifications = [
    {
      id: "1",
      title: "Mission Completed & Verified!",
      desc: "SQL Window Analytics Mission passed (94.5%). Added to Skill Passport.",
      time: "10m ago",
      type: "success",
    },
    {
      id: "2",
      title: "Micro-Intervention Ready",
      desc: "Targeted remedial practice for 'SQL Window Functions' is assigned.",
      time: "2h ago",
      type: "info",
    },
    {
      id: "3",
      title: "Knowledge SPOF Alert",
      desc: "PCI-DSS Runbook review is 15 days overdue. Backup required.",
      time: "1d ago",
      type: "warning",
    },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 dark:border-slate-800 bg-white/80 dark:bg-navy-950/80 backdrop-blur-md">
      <div className="flex h-16 items-center justify-between px-4 sm:px-6">
        {/* Left: Brand / Mobile menu trigger */}
        <div className="flex items-center gap-3">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-brand-600 via-indigo-600 to-teal-500 p-0.5 flex items-center justify-center shadow-sm shadow-brand-500/20 group-hover:shadow-brand-500/40 transition-shadow">
              <div className="h-full w-full bg-navy-950 rounded-[7px] flex items-center justify-center">
                <Compass className="h-5 w-5 text-brand-400 group-hover:rotate-45 transition-transform duration-300" />
              </div>
            </div>
            <div>
              <span className="text-base font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-1.5">
                SkillBridge <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 to-teal-400">AI</span>
              </span>
              <span className="hidden sm:block text-[10px] font-medium text-slate-500 dark:text-slate-400 -mt-1 tracking-wider uppercase">
                Continuous Talent Engine
              </span>
            </div>
          </Link>

          {/* Org Pill */}
          {user?.organization_name && (
            <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-xs text-slate-600 dark:text-slate-300">
              <Building className="h-3.5 w-3.5 text-brand-500" />
              <span className="font-medium">{user.organization_name}</span>
            </div>
          )}
        </div>

        {/* Right side controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Demo Persona Switcher */}
          <div className="relative">
            <button
              onClick={() => setShowPersonaMenu(!showPersonaMenu)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border border-brand-500/30 bg-brand-500/10 hover:bg-brand-500/20 text-brand-600 dark:text-brand-300 transition-colors"
              title="Switch demo persona for instant evaluation"
            >
              <Users className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Demo Persona:</span>
              <span className="font-semibold">{user?.full_name?.split(" ")[0] || "Select"}</span>
              <span className="text-[10px] uppercase px-1 py-0.2 bg-brand-600 text-white rounded">
                {user?.role || "GUEST"}
              </span>
              <ChevronDown className="h-3 w-3" />
            </button>

            {showPersonaMenu && (
              <div
                className="absolute right-0 mt-2 w-64 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-navy-900 p-2 shadow-xl z-50 animate-in fade-in slide-in-from-top-2"
                onClick={() => setShowPersonaMenu(false)}
              >
                <div className="px-2 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Switch Active Role Persona
                </div>
                <button
                  onClick={() => switchDemoUser("LEARNER")}
                  className={`w-full flex items-center justify-between p-2 rounded-lg text-left text-xs transition-colors ${
                    user?.role === "LEARNER"
                      ? "bg-brand-50 dark:bg-brand-950/40 text-brand-600 dark:text-brand-300 font-medium"
                      : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
                  }`}
                >
                  <div>
                    <div className="font-medium">Alex Rivera</div>
                    <div className="text-[11px] text-slate-400">Software Associate (Learner)</div>
                  </div>
                  <Badge variant="brand">Learner</Badge>
                </button>

                <button
                  onClick={() => switchDemoUser("MANAGER")}
                  className={`w-full flex items-center justify-between p-2 rounded-lg text-left text-xs transition-colors mt-1 ${
                    user?.role === "MANAGER"
                      ? "bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-300 font-medium"
                      : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
                  }`}
                >
                  <div>
                    <div className="font-medium">Marcus Brody</div>
                    <div className="text-[11px] text-slate-400">Engineering Director (Manager)</div>
                  </div>
                  <Badge variant="info">Manager</Badge>
                </button>

                <button
                  onClick={() => switchDemoUser("ADMIN")}
                  className={`w-full flex items-center justify-between p-2 rounded-lg text-left text-xs transition-colors mt-1 ${
                    user?.role === "ADMIN"
                      ? "bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-300 font-medium"
                      : "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
                  }`}
                >
                  <div>
                    <div className="font-medium">Sarah Chen</div>
                    <div className="text-[11px] text-slate-400">VP of Talent Architecture (Admin)</div>
                  </div>
                  <Badge variant="success">Admin</Badge>
                </button>
              </div>
            )}
          </div>

          {/* Theme Switcher */}
          <button
            onClick={toggleTheme}
            className="h-9 w-9 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Toggle color theme"
          >
            {theme === "dark" ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4 text-indigo-600" />}
          </button>

          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative h-9 w-9 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="Notifications"
            >
              <Bell className="h-4 w-4" />
              <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-brand-500 animate-pulse" />
            </button>

            {showNotifications && (
              <div
                className="absolute right-0 mt-2 w-80 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-navy-900 p-3 shadow-xl z-50 animate-in fade-in"
                onClick={() => setShowNotifications(false)}
              >
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-xs font-semibold text-slate-900 dark:text-white">Recent Activity & Alerts</span>
                  <span className="text-[10px] text-brand-500 font-medium">3 unread</span>
                </div>
                <div className="space-y-2">
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-slate-900 dark:text-white">{n.title}</span>
                        <span className="text-[10px] text-slate-400">{n.time}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{n.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* User Profile */}
          {user ? (
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-brand-600 to-teal-500 flex items-center justify-center text-white text-xs font-bold shadow-sm">
                  {user.full_name?.charAt(0) || "U"}
                </div>
                <div className="hidden sm:block text-left">
                  <div className="text-xs font-medium text-slate-900 dark:text-white leading-none">
                    {user.full_name}
                  </div>
                  <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5 leading-none">
                    {user.department || "Enterprise"}
                  </div>
                </div>
                <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
              </button>

              {showUserMenu && (
                <div
                  className="absolute right-0 mt-2 w-56 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-navy-900 p-2 shadow-xl z-50 animate-in fade-in"
                  onClick={() => setShowUserMenu(false)}
                >
                  <div className="p-2 border-b border-slate-100 dark:border-slate-800">
                    <p className="text-xs font-semibold text-slate-900 dark:text-white">{user.full_name}</p>
                    <p className="text-[11px] text-slate-400 truncate">{user.email}</p>
                    <div className="mt-1.5 flex items-center gap-1.5">
                      <Badge variant="brand">{user.role}</Badge>
                      <span className="text-[10px] text-slate-400">{user.target_role}</span>
                    </div>
                  </div>

                  <div className="py-1">
                    <Link
                      to="/passport"
                      className="flex items-center gap-2 px-3 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors"
                    >
                      <ShieldCheck className="h-3.5 w-3.5 text-brand-500" />
                      <span>Skill Passport</span>
                    </Link>
                    {user.role !== "LEARNER" && (
                      <Link
                        to="/corporate"
                        className="flex items-center gap-2 px-3 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors"
                      >
                        <Building className="h-3.5 w-3.5 text-indigo-500" />
                        <span>Corporate Analytics</span>
                      </Link>
                    )}
                  </div>

                  <div className="pt-1 border-t border-slate-100 dark:border-slate-800">
                    <button
                      onClick={logout}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-md transition-colors"
                    >
                      <LogOut className="h-3.5 w-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                to="/login"
                className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:text-brand-500 transition-colors"
              >
                Sign In
              </Link>
              <Link
                to="/register"
                className="px-3 py-1.5 text-xs font-medium rounded-lg bg-brand-600 hover:bg-brand-700 text-white transition-all shadow-sm"
              >
                Get Started
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
