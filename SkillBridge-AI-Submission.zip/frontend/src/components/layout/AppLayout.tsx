import React from "react";
import { Outlet, useLocation, Link } from "react-router-dom";
import { Navbar } from "./Navbar";
import { Sidebar } from "./Sidebar";
import { ChevronRight, Home } from "lucide-react";

export const AppLayout: React.FC = () => {
  const location = useLocation();

  const getBreadcrumbs = () => {
    const paths = location.pathname.split("/").filter(Boolean);
    const breadcrumbs = [{ name: "Home", path: "/dashboard" }];

    let current = "";
    for (const p of paths) {
      current += `/${p}`;
      const name = p
        .split("-")
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
        .join(" ");
      breadcrumbs.push({ name, path: current });
    }
    return breadcrumbs;
  };

  const breadcrumbs = getBreadcrumbs();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-navy-950 flex flex-col antialiased selection:bg-brand-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar />

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <Sidebar />

        {/* Content area */}
        <main className="flex-1 overflow-y-auto min-w-0 flex flex-col justify-between">
          <div className="p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">
            {/* Breadcrumbs */}
            {location.pathname !== "/" && location.pathname !== "/dashboard" && (
              <nav className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                <Link
                  to="/dashboard"
                  className="hover:text-slate-900 dark:hover:text-white flex items-center gap-1 transition-colors"
                >
                  <Home className="h-3.5 w-3.5" />
                  <span>Dashboard</span>
                </Link>
                {breadcrumbs.slice(1).map((b, idx) => (
                  <React.Fragment key={b.path}>
                    <ChevronRight className="h-3 w-3 text-slate-400" />
                    {idx === breadcrumbs.length - 2 ? (
                      <span className="font-semibold text-slate-900 dark:text-white truncate">
                        {b.name}
                      </span>
                    ) : (
                      <Link
                        to={b.path}
                        className="hover:text-slate-900 dark:hover:text-white transition-colors truncate"
                      >
                        {b.name}
                      </Link>
                    )}
                  </React.Fragment>
                ))}
              </nav>
            )}

            {/* Routed View */}
            <Outlet />
          </div>

          {/* Footer */}
          <footer className="border-t border-slate-200/80 dark:border-slate-800/80 py-6 px-6 text-xs text-slate-500 dark:text-slate-400 mt-12 bg-white/50 dark:bg-navy-950/50">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  SkillBridge AI
                </span>
                <span>•</span>
                <span>Corporate Continuous Talent & Skill Verification Engine</span>
              </div>
              <div className="flex items-center gap-4 text-[11px]">
                <span className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                  Deterministic & AI Fallback Operational
                </span>
                <span>Privacy & Multi-Org Isolation Guaranteed</span>
              </div>
            </div>
          </footer>
        </main>
      </div>
    </div>
  );
};
